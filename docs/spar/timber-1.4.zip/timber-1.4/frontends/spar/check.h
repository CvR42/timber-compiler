/* File: check.h
 *
 * Header file for check.c
 */

extern bool check_SparProgram( SparProgram p );
