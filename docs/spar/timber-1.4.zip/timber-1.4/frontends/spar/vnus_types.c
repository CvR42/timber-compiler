/* File: vnus_types.c
 *
 * Routines to support the implementation of the vnus types.
 */

#include <tmc.h>

#include "defs.h"
#include "vnus_types.h"
#include "tmadmin.h"
#include "error.h"
#include "ctype.h"

static int decode_char( const char c )
{
    if( isdigit( c ) ){
	return c-'0';
    }
    if( c>='a' && c<= 'f' ){
	return 0xa+c-'a';
    }
    if( c>='A' && c<= 'F' ){
	return 0xa+c-'A';
    }
    return -1;
}

vnus_long string_to_vnus_long( const char *p )
{
    vnus_long val = 0;
    int base = 10;

    while( isspace( *p ) ){
	p++;
    }
    if( *p == '0' ){
	base = 8;
	p++;
	if( *p == 'x' || *p == 'X' ){
	    base = 16;
	    p++;
	}
    }
    for(;;){
	int code = decode_char( *p++ );
	if( code<0 ){
	    break;
	}
	val *= base;
	val += code;
    }
    return val;
}

vnus_int string_to_vnus_int( const char *p )
{
    vnus_int val;
    int res;

    res = sscanf( p, "%i", &val );
    if( res == 0 ){
	internal_error( "number string cannot be converted" );
	val = 0;
    }
    return val;
}

void fprint_vnus_long( FILE *f, const vnus_long val )
{
#ifdef __GNUC__
    __extension__ fprintf( f, "%lld", val );
#endif
}
