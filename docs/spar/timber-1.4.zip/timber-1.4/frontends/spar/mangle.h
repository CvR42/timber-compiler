/* File: mangle.h */

extern SparProgram mangle_SparProgram( SparProgram t );
