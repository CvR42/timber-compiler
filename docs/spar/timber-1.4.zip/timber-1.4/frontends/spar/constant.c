/* File: constant.c
 *
 * Evaluate and check constant expressions.
 */

#include <tmc.h>

#include "defs.h"
#include "tmadmin.h"
#include "error.h"

vnus_long evaluate_char_constant( const char *s )
{
    vnus_long v = s[0];

    switch( s[0] ){
	case '\\':
	    // See JLS2 3.10.6 for the table I got this from.
	    switch( s[1] ){
		case 'b':	v = 0x08;	break;
		case 't':	v = 0x09;	break;
		case 'n':	v = 0x0a;	break;
		case 'f':	v = 0x0c;	break;
		case 'r':	v = 0x0d;	break;
		case '"':	v = 0x22;	break;
		case '\'':	v = 0x27;	break;
		case '\\':	v = 0x5c;	break;

		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		    v = s[1]-'0';
		    if( s[2]>='0' && s[2]<='7' ){
			v *= 8;
			v += s[2]-'0';
			if( s[3]>='0' && s[3]<='7' ){
			    v *= 8;
			    v += s[3]-'0';
			}
		    }
		    break;

		case 'u':
		{
		    const char *p = s+1;
		    while( *p == 'u' ){
			p++;
		    }
		    v = strtol( p, NULL, 16 );
		    break;
		}

		default:
		    v = s[1];
	    }
	    break;

	default:
	    v = s[0];
	    break;
    }
    return v;
}

vnus_long evaluate_integral_constant( const expression x )
{
    switch( x->tag ){
	case TAGByteExpression:
	    return to_ByteExpression(x)->v;

	case TAGShortExpression:
	    return to_ShortExpression(x)->v;
	    
	case TAGIntExpression:
	    return to_IntExpression(x)->v;

	case TAGLongExpression:
	    return to_LongExpression(x)->v;

	case TAGCharExpression:
	    return evaluate_char_constant( to_CharExpression(x)->c );

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGBooleanExpression:
	case TAGCastExpression:
	case TAGClassExpression:
	case TAGClassIdExpression:
	case TAGClassInstanceOfExpression:
	case TAGComplexExpression:
	case TAGConstructorInvocationExpression:
	case TAGDefaultValueExpression:
	case TAGDoubleExpression:
	case TAGFieldExpression:
	case TAGFieldInvocationExpression:
	case TAGFloatExpression:
	case TAGForcedCastExpression:
	case TAGGetBufExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGIfExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGNotNullAssertExpression:
	case TAGNullExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGOuterThisExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGSizeofExpression:
	case TAGStringExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGTypeExpression:
	case TAGTypeFieldExpression:
	case TAGTypeInstanceOfExpression:
	case TAGTypeInvocationExpression:
	case TAGVariableNameExpression:
	case TAGVectorExpression:
	case TAGWhereExpression:
	    internal_error( "Bad expression in integral constant" );
	    break;

	case TAGVectorSubscriptExpression:
	    // TODO: do somethings smarter than this.
	    internal_error( "Bad expression in integral constant" );
	    break;

	case TAGUnopExpression:
	{
	    UnopExpression ux = to_UnopExpression(x);
	    long v = evaluate_integral_constant( ux->operand );

	    switch( ux->optor ){
		case UNOP_NOT:
		    internal_error( "Bad operator in integral constant" );
		    break;

		case UNOP_INVERT:
		    return ~v;

		case UNOP_PLUS:
		    return v;

		case UNOP_NEGATE:
		    return -v;
	    }
	}

	case TAGBinopExpression:
	{
	    BinopExpression bx = to_BinopExpression(x);
	    long a = evaluate_integral_constant( bx->left );
	    long b = evaluate_integral_constant( bx->right );

	    switch( bx->optor ){
		case BINOP_AND:
		    return a&b;

		case BINOP_OR:
		    return a|b;

		case BINOP_MOD:
		    if( b == 0 ){
			return 0;
		    }
		    return a%b;

		case BINOP_PLUS:
		    return a+b;

		case BINOP_MINUS:
		    return a-b;

		case BINOP_TIMES:
		    return a*b;

		case BINOP_DIVIDE:
		    if( b == 0 ){
			return 0;
		    }
		    return a/b;

		case BINOP_XOR:
		    return a^b;

		case BINOP_SHIFTLEFT:
		    return a<<b;

		case BINOP_SHIFTRIGHT:
		    return a>>b;

		case BINOP_USHIFTRIGHT:
		    return ((unsigned long) a)>>b;

		case BINOP_EQUAL:
		case BINOP_NOTEQUAL:
		case BINOP_LESS:
		case BINOP_LESSEQUAL:
		case BINOP_GREATER:
		case BINOP_GREATEREQUAL:
		case BINOP_SHORTAND:
		case BINOP_SHORTOR:
		    internal_error( "Bad operator in integral constant" );
		    break;
	    }
	}

	case TAGAnnotationExpression:
	    return evaluate_integral_constant( to_AnnotationExpression(x)->x );
    }
    return 0;
}
