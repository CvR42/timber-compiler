/* File: constant.h */

extern vnus_long evaluate_char_constant( const char *s );
extern vnus_long evaluate_integral_constant( const expression x );
