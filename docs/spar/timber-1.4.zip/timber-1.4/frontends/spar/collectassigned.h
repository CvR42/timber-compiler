// File: collectassigned.h

extern void collectassigned_statement_list( const_statement_list decl, tmsymbol_list *vars, bool *inv );
extern void collectassigned_Block( const_Block decl, tmsymbol_list *vars, bool *inv );
