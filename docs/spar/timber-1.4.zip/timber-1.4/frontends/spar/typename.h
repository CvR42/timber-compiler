/* File: typename.h */

extern tmstring typename_type( const_type t );
extern tmstring typename_formals( const_FormalParameter_list formals );
extern tmstring typename_Signature( const_Signature t );
