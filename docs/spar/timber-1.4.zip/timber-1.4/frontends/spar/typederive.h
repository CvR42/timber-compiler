/* File: typederive.h */

extern bool derive_natural_constant( const expression x, long int *val );
extern type derive_type_name( const_Entry_list symtab, const_origsymbol nm );
extern type derive_type_name( const_Entry_list symtab, const tmsymbol nm );
extern type derive_type_FormalParameter( const_FormalParameter arg );
extern type_list derive_type_FormalParameter_list( const_FormalParameter_list pl );
extern type derive_type_expression( const_Entry_list symtab, const_expression x );
extern type_list derive_type_expression_list( const_Entry_list symtab, const_expression_list x );
extern type derive_type_optexpression( const_Entry_list symtab, const_optexpression x );

/* Type classification functions. */
extern type max_types( const type ta, const type tb );
extern bool is_identity_conv_type( const_Entry_list symtab, const_type ta, const_type tb );

extern bool is_invocationequivalent_type_list( const_Entry_list symtab, const_TypeEntry_list typelist, const_type_list from, const_type_list to );
extern bool is_invocationequivalent_type( const_Entry_list symtab, const_TypeEntry_list typelist, const_type from, const_type to );
extern bool is_assignequivalent_type( const_Entry_list symtab, const_TypeEntry_list typelist, const_type from, const_type to );
extern bool is_assignequivalent_type_list( const_Entry_list symtab, const_TypeEntry_list typelist, const_type_list tlhs, const_type_list trhs );
extern bool is_numeric_type( const_Entry_list symtab, const_type t );
extern bool is_integral_type( const_Entry_list symtab, const_type t );
extern bool is_complex_type( const_Entry_list symtab, const_type t );
extern bool is_boolean_type( const_Entry_list symtab, const_type t );
extern bool is_valid_cast( const_Entry_list symtab, const_TypeEntry_list typelist, const_type from, const_type to );

extern bool is_interface_type( const_TypeEntry_list typelist, const_type t );
extern bool is_interface_type( const_TypeEntry_list typelist, const_origsymbol name );

extern bool is_widening_prim_basetype( const BASETYPE from, const BASETYPE to );
