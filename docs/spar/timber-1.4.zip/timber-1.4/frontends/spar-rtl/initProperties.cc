// File: initProperties.cc
//

#include <vnustypes.h>
#include <vnusstd.h>
#include "spar-rtl.h"

void *Java_java_lang_System_initProperties( void *ths )
{
    return ths;
}
