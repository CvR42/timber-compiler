extern tmsymbol_list collectscopes_block( const_block blk );
