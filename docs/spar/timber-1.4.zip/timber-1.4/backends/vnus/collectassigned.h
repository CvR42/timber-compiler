// File: collectassigned.h

extern void collectassigned_statement_list( const_statement_list decl, tmsymbol_list *vars, bool *inv );
extern void collectassigned_block( const_block decl, tmsymbol_list *vars, bool *inv );
