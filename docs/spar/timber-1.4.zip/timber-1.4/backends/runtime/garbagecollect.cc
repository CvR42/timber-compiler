// File: garbagecollect.cc

#include "vnustypes.h"
#include "garbagecollect.h"

VnusInt VnusEventGarbageCollect()
{
    return 0;
}
