//
// This is code generated through Tm.
//
/*
 * Distributed write operations do not use barriers
 */

#include "vnusstio.h"
#include "ioseq.h"
#include "iopar.h"
#include "../runtime/vnusrtl.h"
#include <stdio.h>

VnusInt vp__writeByte(VnusInt fileHandle, const VnusByte elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeByte(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeShort(VnusInt fileHandle, const VnusShort elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeShort(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeInt(VnusInt fileHandle, const VnusInt elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeInt(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeLong(VnusInt fileHandle, const VnusLong elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeLong(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeFloat(VnusInt fileHandle, const VnusFloat elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeFloat(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeDouble(VnusInt fileHandle, const VnusDouble elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeDouble(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeComplex(VnusInt fileHandle, const VnusComplex elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeComplex(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeBoolean(VnusInt fileHandle, const VnusBoolean elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeBoolean(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeChar(VnusInt fileHandle, const VnusChar elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeChar(fileHandle, elt);
    }
    return result;
}
VnusInt vp__writeString(VnusInt fileHandle, const VnusString elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__writeString(fileHandle, elt);
    }
    return result;
}
