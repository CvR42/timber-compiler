/* File: shape.cc */

#include "shape.h"
#include <stdarg.h>
#include "vnusrtl.h"
#include <vnusstd.h>
