/* file: main.c
 *
 * main(), initialization and termination.
 */

/* standard UNIX libaries */
#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <errno.h>
/* the tm support library */
#include <tmc.h>

#include "defs.h"
#include "tmadmin.h"
#include "error.h"
#include "global.h"
#include "parser.h"
#include "lex.h"
#include "symbol_table.h"
#include "check.h"
#include "mangle.h"
#include "fwdregtype.h"
#include "regtype.h"
#include "rewrite.h"
#include "lower.h"
#include "prettyprint.h"
#include "version.h"
#include "service.h"
#include "config.h"
#include "constfold.h"
#include "doimports.h"
#include "markused.h"
#include "addgc.h"
#include "markadmin.h"

static FILE *infile;
static FILE *outfile;
static tmstring infilename = tmstringNIL;
static tmstring outfilename = tmstringNIL;
static tmstring errfilename = tmstringNIL;

static int parseonly = FALSE;
static int dontcheck = FALSE;
static int restrict_nostring = FALSE;
static int restrict_nocards = FALSE;
static int restrict_nocomplex = FALSE;
static int restrict_nodelete = FALSE;
static int restrict_noeach = FALSE;
static int restrict_noinline = FALSE;
static int restrict_nopragma = FALSE;
static int restrict_noprint = FALSE;
static int restrict_javaarray = FALSE;
static int restrict_java = FALSE;
static int dumploweredtree = FALSE;

/* Table of debugging flags plus associated information.

   Table is ended by an entry with flagchar '\0'
 */
dbflag flagtab[] = {
    { 'D', &dumpmangledtree, "dump mangled parse tree" },
    { 'I', &trace_inlining, "trace inlining" },
    { 'L', &trace_innerclasses, "trace transformations of inner, local and anonymous classes" },
    { 'S', &trace_symtab, "trace symbol table construction" },
    { 'a', &trace_analysis, "trace program analysis" },
    { 'b', &trace_bindings, "trace the binding of shorthand types" },
    { 'c', &dontcheck, "do not check the parse tree before code generation" },
    { 'd', &dumptree, "dump the parse tree" },
    { 'f', &trace_files, "trace file imports" },
    { 'g', &parseonly, "do not generate code" },
    { 'i', &trace_imports, "trace source file searching for imports" },
    { 'l', &dumploweredtree, "dump parse tree after lowering phase" },
    { 'm', &showmangling, "show translations done by name mangling" },
    { 'o', &showmethodbinding, "show the binding of signatures to methods" },
    { 'p', &trace_generics, "trace the handling of parameterized types" },
    { 's', &givestat, "show allocation statistics" },
    { 't', &trace_typelist, "trace the construction of the type list" },
    { 'u', &trace_usage, "show usage administration maintainance" },
    { 'v', &trace_vtable, "trace construction of the vtables" },
    { 'x', &lextr, "trace lexical analysis" },
    { 'y', &yydebug, "trace yacc operations" },
    { '\0', 0, "" },
};

struct warning {
    const char *name;
    int *flag;
    const char *descr;
};

struct warning warnings[] = {
    { "ignoredvalue", &warn_ignoredvalue, "warn about values returned from methods that are ignored" },
    { "semicolon", &warn_semicolon, "warn about ';' after a class or method declaration" },
    { 0, 0, 0 }
};

/* Given a warning string 'str', a table of warning flags 'table', and
 * a pointer to an index 'posp', return false if the string can not be found
 * in the table, or return true if the string can be found, and set '*posp'
 * to the position of the string in the table.
 */
static bool find_warn_flag( const char *flag, struct warning *table, unsigned int *posp )
{
    unsigned int ix = 0;

    while( table[ix].name != 0 ){
	if( strcmp( table[ix].name, flag ) == 0 ){
	    *posp = ix;
	    return true;
	}
	ix++;
    }
    return false;
}

/* Given a file handle 'f' and a table of warning flags 'table', print
 * an overview of the flags in the table to the given file.
 */
static void helpwarnflags( FILE *f, struct warning *table )
{
    unsigned int ix;
    unsigned int pos;
    size_t maxlen = strlen( "all" );

    fputs( "\nWarning flags:\n", f );
    ix = 0;
    while( table[ix].name != 0 ){
	size_t len = strlen( table[ix].name );

	if( len>maxlen ){
	    maxlen = len;
	}
	ix++;
    }
    ix = 0;
    while( table[ix].name != 0 ){
	pos = strlen( table[ix].name );
	fputc( ' ', f );
	fputs( table[ix].name, f );
	while( pos<maxlen ){
	    fputc( ' ', f );
	    pos++;
	}
	fputc( ' ', f );
	fputs( table[ix].descr, f );
	fputc( '\n', f );
	ix++;
    }
    pos = strlen( "all" );
    fputs( " all", f );
    while( pos<maxlen ){
	fputc( ' ', f );
	pos++;
    }
    fputs( " set all warning flags\n", f );
    fputs( "A flag can be reset by prefixing it with 'no'.\n", f );
}

/* Given a string that should contain a warning flag, and a table of
 * flags, try to find the string in the table, and set that flag.
 *
 * If the special flag "all" is given, *all* flags in the table are
 * set. If the flag is not found, but it contains the prefix 'no', and
 * the remainder matches a flag, that flag is reset.
 */
static void set_warn_flag( const char *flag, struct warning *table )
{
    unsigned int pos;

    if( strcmp( flag, "all" ) == 0 ){
	unsigned int ix = 0;

	while( table[ix].name != 0 ){
	    *(table[ix].flag) = 1;
	    ix++;
	}
    }
    if( find_warn_flag( flag, table, &pos ) ){
	*(table[pos].flag) = 1;
    }
    else if(
	flag[0] == 'n' &&
	flag[1] == 'o' &&
	find_warn_flag( flag+2, table, &pos )
    ){
	*(table[pos].flag) = 0;
    }
}

struct option long_options[] = {
    { "arrayclass", no_argument, &array_class, 1 },
    { "help", no_argument, 0, 'h' },
    { "java", no_argument, &restrict_java, 1 },
    { "java-array", no_argument, &restrict_javaarray, 1 },
    { "noboundscheck", no_argument, &no_boundscheck, 1 },
    { "nocards", no_argument, &restrict_nocards, 1 },
    { "nocomplex", no_argument, &restrict_nocomplex, 1 },
    { "nodelete", no_argument, &restrict_nodelete, 1 },
    { "noeach", no_argument, &restrict_noeach, 1 },
    { "nogc", no_argument, &pref_nogarbagecollection, 1 },
    { "noinline", no_argument, &restrict_noinline, 1 },
    { "noinlining", no_argument, &no_inlining, 1 },
    { "nonotnullassert", no_argument, &pref_nonotnullassert, 1 },
    { "nopragma", no_argument, &restrict_nopragma, 1 },
    { "noprint", no_argument, &restrict_noprint, 1 },
    { "nostring", no_argument, &restrict_nostring, 1 },
    { "strictanalysis", no_argument, &pref_strictanalysis, 1 },
    { "version", no_argument, 0, 2 },
    { 0, 0, 0, 0 }
};

/* Print version number to file 'f'. */
static void show_version( FILE *f )
{
    fprintf( f, "Spar frontend version: %s\n", spar_version );
}

/* Print usage message to file 'f'. */
static void show_usage( FILE *f )
{
    show_version( f );
    fputs(
"\n"
"Usage: sparfront [-d<debugflags>] [-o <outfile>] <infile>\n"
"or   : sparfront -h\n"
"\n"
"Flags:\n"
"-d <debugflags>: Switch on given debug flags (see below).\n"
"-e <outfile>:    Write errors to given file (default: standard error).\n"
"-h, --help:      Show this help text.\n"
"-o <outfile>:    Write output to given file (default: standard out).\n"
"--version:       Show the version number of the program.\n"
"-W <warnflag>:   Switch on given warning flag (see below).\n"
"--nocards:       Do not allow cardinality lists.\n"
"--nocomplex:     Do not treat 'complex' as a keyword (so no complex type).\n"
"--nodelete:      Do not treat 'delete' as a keyword.\n"
"--noeach:        Do not treat 'each' and 'foreach' as keywords.\n"
"--strictanalysis:Keep analysis strictly conformant with Java.\n"
"--noinline:      Do not allow 'inline' keyword.\n"
"--noinlining:    Do not automatically inline any methods.\n"
"--nopragma:      Do not allow pragmas.\n"
"--noboundscheck: Do not generate code for bounds checking.\n"
"--noprint:       Do not treat '__print' and '__println' as keywords.\n"
"--java-array:    Only allow Java array declarations.\n"
"--java:          Restrict input to the Java subset (equivalent to --nocards\n"
"                 --nocomplex --nodelete --noeach --noinline --nopragma\n"
"                 --noprint --java-array).\n"
        ,
	f
    );
    helpwarnflags( f, warnings );
    fputs( "\n", f );
    helpdbflags( f, flagtab );
}

/* Construct the search path for Spar sources.
 *
 * Before anything else, the sparpath is populated with the values of
 * DEVEL_SPARLIB_PATH, INSTALL_SPARLIB_PATH and the environment variable
 * KAFFELIB_PATH. DEVEL_SPARLIB_PATH is only valid in the development
 * environment. INSTALL_SPARLIB_PATH points to the directory where the
 * sparlib stuff would be installed (but might not be during development).
 * KAFFELIB_PATH points to the path where the kaffe library is installed.
 *
 * We do not have any control over the last one; we can only hope that
 * the user has set that environment variable right.
 *
 * After all this standard stuff, all paths in SPARPATH are appended.
 * These are supposed to point to user libraries.
 */
static void construct_sparpath()
{
    sparpath = new_tmstring_list();

    sparpath = append_tmstring_list(
	sparpath,
	new_tmstring( DEVEL_SPARLIB_PATH )
    );
    sparpath = append_tmstring_list(
	sparpath,
	new_tmstring( INSTALL_SPARLIB_PATH )
    );

    const char *kaffepath = getenv( "KAFFEROOT" );
    if( kaffepath == NULL ){
	fprintf( stderr, "You must set environment variable KAFFEROOT\n" );
	exit( 2 );
    }
    if( kaffepath[0] == '\0' ){
	fprintf( stderr, "an empty KAFFEROOT is not acceptable\n" );
	exit( 2 );
    }
    tmstring long_kaffepath = printf_tmstring( "%s/libraries/javalib", kaffepath );
    sparpath = append_tmstring_list( sparpath, long_kaffepath );
    const char *pathstring = getenv( "SPARPATH" );

    if( pathstring != NULL ){
	tmstring buf = rdup_tmstring( pathstring );
	char *p = buf;

	while( p[0] != '\0' ){
	    char *cp = strchr( p, ':' );
	    char *nextp;

	    if( cp != NULL ){
		/* a ':' was found. */
		nextp = cp+1;
	    }
	    else {
		cp = p+strlen( p );
		nextp = cp;
	    }
	    if( cp>p && cp[-1] == PATHSEP ){
		/* Zap path separator at the end of the path. */
		cp[-1] = '\0';
	    }
	    cp[0] = '\0';
	    sparpath = append_tmstring_list( sparpath, new_tmstring( p ) );
	    p = nextp;
	}
	rfre_tmstring( buf );
    }
}

// We cannot find SANITYCHECK_CLASS. Something must be very rotten, so
// complain.
static void complain_bad_sparpath( FILE *f )
{
    fprintf(
	f,
	"The class '" SANITYCHECK_CLASS "' cannot be found. Something must be wrong.\n"
    );
    fprintf(
	f,
	"I have searched the following directories:\n" 
    );
    if( sparpath == NULL ){
	fputs( "(sparpath is null.)\n", f );
    }
    else {
	for( unsigned int ix=0; ix<sparpath->sz; ix++ ){
	    fputs( sparpath->arr[ix], f );
	    fputc( '\n', f );
	}
    }
}

/* Same as fopen, but give error message if file can't be opened */
static FILE *ckfopen( const char *nm, const char *acc )
{
    FILE *hnd = fopen( nm, acc );

    if( NULL == hnd ){
	(void) strcpy( errarg, nm );
	sys_error( errno );
	exit( 2 );
    }
    return hnd;
}

/* Similar to freopen, but give error message if file can't be opened.
 * Therefore, file handle need not be returned.
 */
static void ckfreopen( const char *nm, const char *acc, FILE *f )
{
    if( freopen( nm, acc, f ) == NULL ){
	(void) strcpy( errarg, nm );
	sys_error( errno );
	exit( 1 );
    }
}

/* Scan arguments and options. */
static void scanargs( int argc, char *argv[] )
{
    int option_index = 0;

    for(;;){
	int c = getopt_long(
	    argc,
	    argv,
	    "W:d:e:ho:",
	    long_options,
	    &option_index
	);
	if( c == EOF ){
	    break;
	}
	switch( c ){
	    case 0:
		break;

	    case 2:
		show_version( stdout );
		exit(0);

	    case 'W':
		set_warn_flag( optarg, warnings );
		break;

	    case 'd':
		setdbflags( optarg, flagtab, TRUE );
		break;

	    case 'e':
		if( errfilename != tmstringNIL ){
		    rfre_tmstring( errfilename );
		}
		errfilename = new_tmstring( optarg );
		break;

	    case 'h':
		show_usage( stdout );
		exit(0);

	    case 'o':
		if( outfilename != tmstringNIL ){
		    rfre_tmstring( outfilename );
		}
		outfilename = new_tmstring( optarg );
		break;

	    case ':':
		fprintf( stderr, "Missing parameter for option '%c'", optopt );
		exit( 1 );

	    case '?':
	    default:
		show_usage( stderr );
		exit( 1 );
	}
    }
    if( optind<argc ){
	if( optind+1<argc ){
	     fprintf( stderr, "At most one input file can be given\n" );
	    show_usage( stderr );
	    exit( 1 );
	}
	rfre_tmstring( infilename );
	infilename = new_tmstring( argv[optind] );
	infile = ckfopen( infilename, "r" );
    }
    if( restrict_nostring ){
	spar_features &= ~FEAT_STRING;
    }
    if( restrict_nocomplex ){
	spar_features &= ~FEAT_COMPLEX;
    }
    if( restrict_nopragma ){
	spar_features &= ~FEAT_PRAGMA;
    }
    if( restrict_nodelete ){
	spar_features &= ~FEAT_DELETE;
    }
    if( restrict_noeach ){
	spar_features &= ~FEAT_PARALLEL;
    }
    if( restrict_noinline ){
	spar_features &= ~FEAT_INLINE;
    }
    if( restrict_noprint ){
	spar_features &= ~FEAT_PRINT;
    }
    if( restrict_nocards ){
	spar_features &= ~FEAT_CARDS;
    }
    if( restrict_javaarray ){
	spar_features &= ~FEAT_ARRAY;
    }
    if( restrict_java ){
	spar_features = FEAT_JAVA;
    }
    java_features = FEAT_JAVA;
}

// Given a list of declarations that form the body of the main class
// search for a method 'main' without any parameters. If there is
// one, this will be invoked. IF there is no other method 'main',
// or if all other methods 'main' have more than one parameter, complain.
static bool has_short_main( statement_list decls )
{
    bool has_candidate_main = false;
    tmsymbol main = add_tmsymbol( "main" );

    for( unsigned int ix=0; ix<decls->sz; ix++ ){
	statement s = decls->arr[ix];

	if( s->tag == TAGFunctionDeclaration ){
	    FunctionDeclaration fn = to_FunctionDeclaration( s );

	    if( fn->name->sym == main ){
		if( fn->parameters->sz == 0 ){
		    // We know the answer: there *is* a 'main()' method.
		    return true;
		}
		if( fn->parameters->sz == 1 ){
		    has_candidate_main = true;
		}
	    }
	}
    }
    if( !has_candidate_main ){
	error( "There is no 'main()' or 'main( String v[] )' method" );
    }
    return false;
}

// Given a SparProgramUnit 'unit', return the name of the (first)
// public class or interface of this unit.
//
// This class presumably has the main method.
static TypeDeclaration search_main_type( const SparProgramUnit unit )
{
    statement_list decls = unit->decls;

    for( unsigned int ix=0; ix<decls->sz; ix++ ){
	statement decl = decls->arr[ix];

	if( is_TypeDeclaration( decl ) ){
	    if( to_declaration( decl )->flags & ACC_PUBLIC ){
		return to_TypeDeclaration( decl );
	    }
	}
    }
    return TypeDeclarationNIL;
}

// Construct a wrapper method to build the correct argument vector
// and invoke 'main( String argv[] )' with it. If there is a 'main()'
// method, this wrapper method is never invoked, so it won't be compiled,
// and the incorrect invocation of 'main( String argv[] )' is not
// exposed.
static MethodDeclaration build_main_wrapper()
{
    origsymbol methodnm = gen_origsymbol( "main" );
    statement_list statements = new_statement_list();
    MethodInvocationExpression argv_build = new_MethodInvocationExpression(
	new_MethodInvocation(
	    expressionNIL,		// vtable
	    add_origsymbol( "spar.compiler.Argv.buildArgv" ),
	    new_expression_list(),	// This parameters
	    new_expression_list(),	// Parameters
	    0
	)
    );
    statement invocation = new_MethodInvocationStatement(
	gen_origin(),
	Pragma_listNIL,
	origsymbol_listNIL,	// Labels
	new_MethodInvocation(
	    expressionNIL,		// vtable
	    add_origsymbol( "main" ),
	    new_expression_list(),		// This parameter
	    append_expression_list(
		new_expression_list(),
		argv_build
	    ),
	    0
	)
    );
    Block fnbody = new_Block( tmsymbolNIL, Pragma_listNIL, statements );

    statements = append_statement_list(
	statements,
	invocation
    );
    type_list throws = new_type_list();
    // This wrapper function has the clause 'throws java.lang.Throwable',
    // since we don't want complaints about invoking the real main
    // if it has a throws clause.
    throws = append_type_list(
	throws,
	new_ObjectType( add_origsymbol( "java.lang.Throwable" ) )
    );
    return new_FunctionDeclaration(
	gen_origin(),
	Pragma_listNIL,
	origsymbol_listNIL,		// Labels
	ACC_STATIC|ACC_FINAL,
	TMFALSE,			// used?
	methodnm,
	new_FormalParameter_list(),	// Formal parameters
	throws,				// Throws clause
	new_VoidType(),
	fnbody
    );
}

static SparProgram wrap_topunit( SparProgramUnit topunit, const char *fnm )
{
    tmsymbol mn;
    SparProgram theprog;
    TypeBinding_list typebindings;
    tmsymbol packagename = tmsymbolNIL;
    TypeDeclaration main_type = search_main_type( topunit );

    if( main_type == TypeDeclarationNIL ){
	error( "No public class defined in main compilation unit" );
	return SparProgramNIL;
    }
    if( has_short_main( main_type->body ) ){
	mn = add_tmsymbol( "main" );
    }
    else {
	MethodDeclaration wrapper = build_main_wrapper();
	main_type->body = append_statement_list( main_type->body, wrapper );
	mn = wrapper->name->sym;
    }
    mn = qualify_tmsymbol( main_type->name->sym, mn );
    if( topunit->packagename != origsymbolNIL ){
	packagename = topunit->packagename->sym;
	mn = qualify_tmsymbol( packagename, mn );
    }
    typebindings = new_TypeBinding_list();
    if( topunit->packagename != origsymbolNIL ){
	typebindings = append_TypeBinding_list(
	    typebindings,
	    new_TypeBinding( packagename, packagename )
	);
    }
    theprog = new_SparProgram(
	rdup_Pragma_list( topunit->pragmas ),
	append_SparProgramUnit_list( new_SparProgramUnit_list(), topunit ),
	new_tmsymbol_list(),		/* inits */
	new_GenericMapping_list(),
	mn,				/* The name of the main program. */
	add_tmsymbol( EXCEPTION_HANDLER_NAME ),
	tmsymbolNIL,
	tmsymbolNIL,
	tmsymbolNIL,
	tmsymbolNIL,
	new_TypeEntry_list(),
	new_Entry_list(),
	typebindings
    );
    fwdregtype_SparProgramUnit( &theprog, topunit );
    regtype_SparProgramUnit( &theprog, topunit, fnm );
    return theprog;
}

int main( int argc, char *argv[] )
{
    SparProgramUnit topunit;
    SparProgram theprog;

#if 0
    mtrace();
#endif

    construct_sparpath();
    infile = stdin;
    outfile = stdout;
    infilename = new_tmstring( "" );
    init_lex();
    scanargs( argc, argv );
    if( outfilename != tmstringNIL ){
	outfile = ckfopen( outfilename, "w" );
    }
    if( errfilename != tmstringNIL ){
        ckfreopen( errfilename, "w", stderr );
    }
    if( !java_lang_visible() ){
	complain_bad_sparpath( stderr );
	exit( 2 );
    }
    topunit = parse( infile, infilename, has_java_suffix( infilename ) );
    errcheck();
    topunit = lower_SparProgramUnit( topunit );
    if( dumploweredtree ){
	TMPRINTSTATE *st;
	int level;

	st = tm_setprint( stderr, 1, 75, 8, 0 );
	print_SparProgramUnit( st, topunit );
	level = tm_endprint( st );
	if( level>0 ){
	    fprintf( stderr, "Internal botch: bracket level is %d\n", level );
	}
	fflush( stderr );
    }
    theprog = wrap_topunit( topunit, infilename );
    if( dumptree ){
	TMPRINTSTATE *st;
	int level;

	st = tm_setprint( stderr, 1, 75, 8, 0 );
	print_SparProgram( st, theprog );
	level = tm_endprint( st );
	if( level>0 ){
	    fprintf( stderr, "Internal botch: bracket level is %d\n", level );
	}
	fflush( stderr );
    }
    errcheck();
    theprog = mangle_SparProgram( theprog );
    errcheck();
    if( dumpmangledtree ){
	TMPRINTSTATE *st = tm_setprint( stderr, 1, 75, 8, 0 );
	print_SparProgram( st, theprog );
	int level = tm_endprint( st );
	if( level>0 ){
	    fprintf( stderr, "Internal botch: bracket level is %d\n", level );
	}
    }
    theprog = constant_fold_SparProgram( theprog );
    if( !dontcheck ){
	check_SparProgram( theprog );
    }
    errcheck();
    theprog = rewrite_SparProgram( theprog );
    if( !dontcheck ){
	check_SparProgram( theprog );
    }
    errcheck();
    if( no_boundscheck ){
	Pragma p = new_ValuePragma(
	    add_origsymbol( "boundscheck" ),
	    new_BooleanPragmaExpression( TMFALSE )
	);
	theprog->pragmas = insert_Pragma_list( theprog->pragmas, 0, p );
    }
    if( !parseonly ){
	markused_SparProgram( theprog );
	if( !pref_nogarbagecollection ){
	    addgc_SparProgram( theprog );
	}
	pp_SparProgram( outfile, theprog );
    }
    rfre_SparProgram( theprog );
    end_lex();
    fre_tmstring( infilename );
    fre_tmstring( outfilename );
    fre_tmstring( errfilename );
    rfre_tmstring_list( sparpath );
    clear_arraymarkers();
    flush_tmsymbol();
    if( get_balance_tmadmin() != 0 || get_balance_tmstring() != 0 ){
	fprintf( stderr, "Tm object allocation not balanced\n" );
	givestat = true;
    }
    if( givestat ){
	stat_tmadmin( stderr );
	stat_tmstring( stderr );
	report_lognew( stderr );
    }
    flush_lognew();
    exit( 0 );
    return 0;
}
