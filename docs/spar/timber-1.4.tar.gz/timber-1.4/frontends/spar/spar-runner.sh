#
# This is only a partial script. It must be prefixed with a
# configuration file to get it running.
#
CPLUS=g++

# Clear flags to the various phases
CPLUSFLAGS=
VNUSFLAGS=
FRONTFLAGS=
LDFLAGS=
MAPPERFLAGS=

# lists of files
SPARFILES=
VNUSFILES=
CPLUSFILES=
LDFILES=
LIBS=
JUNK=

OUTPUT=a.out
N=0
TRACE=
FAIL=0
KEEPFILES=0
NEEDSPARRTL=1 # always set to one for compiling intermediate C++ files
COMBINE_COMPILE_LINK=0
TARGET=default
PROCNO=default

function showversion()
{
    echo "$0 version $VERSION";
}

function showversions()
{
    showversion
    $FRONT -v
    $VNUS -v
    $CPLUS -v
}

function showusage()
{
    showversion
    cat << EOF
Usage: $0 [options] <file>

Files with the extension '.spar' and '.java' are put through Spar.

Files with the extension '.v' are put through Vnus.

Files with the extensions '.c', '.cc', '.cpp' and '.cxx' are put through C++.

Files with the extensions '.o' and '.a' are linked with the other files.

Options are:
--help            Show this help text
--version         Print the version number of this driving scipt
--versions        Print the version numbers of all components of the script
--keepfiles       Keep intermediate files
--compile-link    Combine compile & link step
--timings
--timer           Enable runtime timer
--nocards
--noboundscheck
--nogc
--nocomplex
--arrayclass	  Passed to Spar frontend
--nodelete
--noeach
--noinline
--noinlining
--nopragma
--noprint
--nonotnullassert
--strictanalysis
--java		  Passed to Spar frontend
--java-array 	  Passed to Spar frontend
-W<flag>	  Passed to Spar frontend
-g                Generate debugging code
-h	          Show this help text
-o <file>	  Write output (executable) to <file>
-O<n>		  Let the C++ backend use optimization level <n>.

-m<flag>          Passed to target C++ compiler
-f<flag>          Passed to target C++ compiler

Sequential targets:

--target=seq      Compile for sequential target (default)
--target=trimedia Compile for sequential Trimedia target

Distributed targets:

--target=das      Compile for DAS cluster (MPI)
--target=lam      Compile for LAM cluster (MPI) -- defunct

-a<n>             Specify number of processors

EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --compile-link)
            COMBINE_COMPILE_LINK=1
            shift
            ;;
	--keepfiles)
	    KEEPFILES=1
	    CPLUSFLAGS="$CPLUSFLAGS"
	    shift
	    ;;
        -das|--target=das)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=das
            shift
            ;;
        -lam|--target=lam)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=lam
            shift
            ;;
        -seq|--target=seq)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=seq
            shift
            ;;
        -trimedia|--target=trimedia)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=trimedia
            COMBINE_COMPILE_LINK=1
            shift
            ;;
        -emb-trimedia)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-trimedia
	    MAPPERFLAGS=
            COMBINE_COMPILE_LINK=1
            shift
            ;;
        -emb-pentium)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-pentium
	    MAPPERFLAGS=
            shift
            ;;
        -emb-trimedia-lus)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-trimedia-lus
	    MAPPERFLAGS=-da
            COMBINE_COMPILE_LINK=1
            shift
            ;;
        -emb-pentium-lus)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-pentium
	    MAPPERFLAGS=-da
            shift
            ;;
	-pg)
	    CPLUSFLAGS="$CPLUSFLAGS -pg"
	    LDFLAGS="$LDFLAGS -pg"
	    shift
	    ;;

        -a*)
            if [ "$PROCNO" != "default" ]; then
              echo "Multiple proc# specified (-p<n>)"
              exit 1
            fi
            PROCNO=$1
            shift
            ;;

	--noinline|--strictanalysis|--noinlining|--nopragma|--noprint|--arrayclass|--nocomplex|--nocards|--nodelete|--java-array|--java|--noeach|-W*|--noboundscheck|--nonotnullassert)
	    FRONTFLAGS="$FRONTFLAGS $1"
	    shift
	    ;;

	--timings)
	    TRACE="time -v"
	    shift
	    ;;

	--timer)
	    VNUSFLAGS="$VNUSFLAGS -dt"
	    shift
	    ;;

	--trace)
	    TRACE=echo
	    shift
	    ;;

	--version)
	    showversion
	    exit 0
	    ;;

	--versions)
	    showversions
	    exit 0
	    ;;

	-o)
	    OUTPUT=$2
	    shift
	    shift
	    ;;

	-g)
	    CPLUSFLAGS="$CPLUSFLAGS -g"
	    LDFLAGS="$LDFLAGS -g"
	    shift
	    ;;

	-O*|-f*|-m*|-save-temps)
	    CPLUSFLAGS="$CPLUSFLAGS $1"
	    shift
	    ;;

	-h | --help)
	    showusage
	    exit 0
	    ;;

	-d*)
	    FRONTFLAGS="$FRONTFLAGS $1"
	    shift
	    ;;

	-l*)
	    LIBS="$LIBS $1"
	    shift
	    ;;

	-*)
	    echo "unknown option '$1'"
	    showusage
	    exit 1
	    ;;

	*.v)
	    VNUSFILES="$VNUSFILES $1"
	    shift
	    ;;

	*.spar|*.java)
	    SPARFILES="$SPARFILES $1"
	    NEEDSPARRTL=1
	    shift
	    ;;

	*.c|*.cc|*.cpp|*.cxx)
	    CPLUSFILES="$CPLUSFILES $1"
	    shift
	    ;;

	*.o)
	    LDFILES="$LDFILES $1"
	    shift
	    ;;

	*.a)
	    LIBFILES="$LIBFILES $1"
	    shift
	    ;;

	*)
	    echo "$0: Don't know what to do with file '$1'"
	    shift
	    FAIL=1
	    ;;
    esac
done

if [ $FAIL = 1 ]; then
    exit 1
fi

if [ "$TARGET" = "default" ] ; then
  TARGET=seq
fi

if [ "$PROCNO" = "default" ] ; then
  PROCNO=-a4
fi

case "$TARGET" in
  seq)
    DISTRIBUTED="no"
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -D__GENERATE_SEQUENTIAL_CODE__ $CPLUSFLAGS"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS"
    LIBFILES="$LIBFILES $VNUSRUNTIMELIB/libvnusrtl-s.a"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;
  trimedia)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    DISTRIBUTED="no"
    CPLUS="tmcc"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS -l"
    CPLUSFLAGS="$CPLUSFLAGS -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -el -host MacOS -tmcfe -Xtmpl=local -- -D__GENERATE_SEQUENTIAL_CODE__"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -tmconfig=$TMDRV_PATH/dsp/lib/tmconfig.linux-i386 -L$VNUSRUNTIMELIB -L$TMDRV_PATH/dsp/lib"
    LIBFILES="$LIBFILES -ltmdrv -ldev -lvnusrtl-ts"
    if [ $NEEDSPARRTL = 1 ]; then
      LDFLAGS="$LDFLAGS -L$SPARRUNTIMELIB"
      LIBFILES="$LIBFILES -lspar-rtl-ts"
    fi
    ;;
  emb-trimedia|emb-trimedia-lus)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    DISTRIBUTED="yes"
    CPLUS="tmcc"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS -l"
    CPLUSFLAGS="$CPLUSFLAGS -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -el -host MacOS -tmcfe -Xtmpl=local -- -D__GENERATE_DISTRIBUTED_CODE__ -D__GENERATE_PTM_CODE__"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -tmconfig=$TMDRV_PATH/dsp/lib/tmconfig.linux-i386 -L$VNUSRUNTIMELIB -L$TMDRV_PATH/dsp/lib"
    LIBFILES="$LIBFILES -lvnusrtl-te $VNUSRUNTIMELIB/embedded/libensemble-trimedia.a -ltmdrv -ldev"
    if [ $NEEDSPARRTL = 1 ]; then
      LDFLAGS="$LDFLAGS -L$SPARRUNTIMELIB"
      LIBFILES="$LIBFILES -lspar-rtl-te"
    fi
    ;;
  emb-pentium|emb-pentium-lus)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    TCS_PATH="/usr/local/src/tcs2.0beta"
    DISTRIBUTED="yes"
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -D__GENERATE_DISTRIBUTED_CODE__ -D__GENERATE_PTM_CODE__ $CPLUSFLAGS"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -L$TMDRV_PATH/linux/lib -L$TCS_PATH/lib/Linux"
    LIBFILES="$VNUSRUNTIMELIB/libvnusrtl-e.a $VNUSRUNTIMELIB/embedded/libensemble-host-i386.a -ltmdrv -lload $LIBFILES"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-e.a $LIBFILES"
    fi
    ;;
  das)
    DISTRIBUTED="yes"
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -D__GENERATE_DISTRIBUTED_CODE__ $CPLUSFLAGS"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS  -L/usr/local/VU/mpi/lib/i386/ch_panda4/optimized -L/usr/local/package/myrinet/lib/intel_linux -L/usr/local/VU/panda/panda4.0/lib/i386_linux/lfc/no_threads/optimized -L/usr/local/package/lfc/lib/optimized -L/usr/local/package/daslib/lib/i386_Linux"
    LIBFILES="$LIBFILES $VNUSRUNTIMELIB/libvnusrtl-m.a -lmpi -lpanda -llfc -lDpi -lLanaiDevice -lbfd -liberty -ldas"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-m.a $LIBFILES"
    fi
    ;;
  lam)
    ;;
esac

#
# Spar frontend phase
#
for f in $SPARFILES; do
    if [ $KEEPFILES = 1 ]; then
	case "$f" in
	    *.spar)
		OUT=`basename $f .spar`.v
		;;

	    *.java)
		OUT=`basename $f .java`.v
		;;

	     *)
		echo "$o: Don't know how to get the basename of file '$f'"
		exit 2
		;;
	esac
    else
	OUT=$TMPDIR/spar$$.$N.v
	N=`expr $N + 1`
	JUNK="$JUNK $OUT"
    fi
    VNUSFILES="$OUT $VNUSFILES"
    $TRACE $FRONT $FRONTFLAGS -o $OUT $f
    if [ $? != 0 ]; then
	$TRACE rm -f $JUNK
	exit 1
    fi
done
#
# Vnus phase
#
if [ "$DISTRIBUTED" = "yes" ]; then
  # sequential vnus -> sequential tm -> distributed tm -> c++
  for f in $VNUSFILES; do
      #sequential vnus -> tm
      if [ $KEEPFILES = 1 ]; then
	  OUT_TM_SEQ=`basename $f .v`-s.tm
      else
  	OUT_TM_SEQ=$TMPDIR/spar$$.$N-s.tm
	N=`expr $N + 1`
	JUNK="$JUNK $OUT_TM_SEQ"
      fi
      $TRACE $VNUS -t $PROCNO $f -o $OUT_TM_SEQ
      #sequential tm -> distributed tm
      if [ $KEEPFILES = 1 ]; then
	  OUT_TM_DIST=`basename $f .v`-d.tm
      else
  	OUT_TM_DIST=$TMPDIR/spar$$.$N-d.tm
	N=`expr $N + 1`
	JUNK="$JUNK $OUT_TM_DIST"
      fi
      echo PERFORMING $MAPPER $MAPPERFLAGS
      $TRACE $MAPPER $MAPPERFLAGS < $OUT_TM_SEQ > $OUT_TM_DIST
      #distributed tm -> c++
      if [ $KEEPFILES = 1 ]; then
	  OUT=`basename $f .v`.cc
      else
  	OUT=$TMPDIR/spar$$.$N.cc
	N=`expr $N + 1`
	JUNK="$JUNK $OUT"
      fi
      CPLUSFILES="$OUT $CPLUSFILES"
      $TRACE $VNUS $VNUSFLAGS -r -p $PROCNO $OUT_TM_DIST -o $OUT
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
  done
else
  # sequential vnus -> c++
  for f in $VNUSFILES; do
      if [ $KEEPFILES = 1 ]; then
	  OUT=`basename $f .v`.cc
      else
  	OUT=$TMPDIR/spar$$.$N.cc
	N=`expr $N + 1`
	JUNK="$JUNK $OUT"
      fi
      CPLUSFILES="$OUT $CPLUSFILES"
      $TRACE $VNUS $VNUSFLAGS $f -o $OUT
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
  done
fi


if [ $COMBINE_COMPILE_LINK = 1 ]; then
    $TRACE $CPLUS $CPLUSFLAGS $LDFLAGS $CPLUSFILES $LDFILES $LIBFILES $LIBS -o $OUTPUT
  {
    if [ $? != 0 ]; then
        $TRACE rm -f $JUNK
        exit 1
    fi
  }
else
  {
    # C++ phase
    for f in $CPLUSFILES; do
        if [ $KEEPFILES = 1 ]; then
	    OUT=`basename $f .cc`.o
        else
	    OUT=$TMPDIR/spar$$.$N.o
            N=`expr $N + 1`
            JUNK="$JUNK $OUT"
        fi
        LDFILES="$OUT $LDFILES"
        $TRACE $CPLUS -c $CPLUSFLAGS $f -o $OUT
        if [ $? != 0 ]; then
	    $TRACE rm -f $JUNK
	    exit 1
        fi
    done
    # link phase
    $TRACE $CPLUS $LDFLAGS $LDFILES $LIBFILES -o $OUTPUT
    if [ $? != 0 ]; then
        $TRACE rm -f $JUNK
        exit 1
    fi
  }
fi

# clean up
$TRACE rm -f $JUNK
