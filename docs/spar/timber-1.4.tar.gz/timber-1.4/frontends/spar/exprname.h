/* File: exprname.h */

extern tmstring name_expression( const_expression x );
extern tmstring name_expression_list( const_expression_list x );
