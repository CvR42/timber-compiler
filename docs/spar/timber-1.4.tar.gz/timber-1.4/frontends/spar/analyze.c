// File: analyze.c
//
// Simple analysis functions.

#include <tmc.h>

#include "defs.h"
#include "config.h"
#include "tmadmin.h"
#include "analyze.h"
#include "service.h"
#include "global.h"
#include "pragma.h"
#include "symbol_table.h"

// Given two AFLAGS, return the result if either one of them can occur.
AFLAG aflag_either( AFLAG a, AFLAG b )
{
    if( a == b ) return a;
    return AF_MAYBE;
}

// Given two AFLAGS, return the result if both of them occur.
AFLAG aflag_both( AFLAG a, AFLAG b )
{
    if( a == AF_YES || b == AF_YES ){
	return AF_YES;
    }
    if( a == AF_MAYBE || b == AF_MAYBE ){
	return AF_MAYBE;
    }
    return AF_NO;
}

// Given two abstract values, return the result if either of them
// can occur.
void abstract_either( AbstractValue a, AbstractValue b )
{
    a->zero = aflag_either( a->zero, b->zero );
    a->positive = aflag_either( a->positive, b->positive );
    a->constant &= b->constant;

    if( !isequal_expression( a->value, b->value ) ){
	rfre_expression( a->value );
	a->value = NULL;
    }
}

// Given two abstract values, return the result if both of them occur.
void abstract_both( AbstractValue a, AbstractValue b )
{
    a->zero = aflag_both( a->zero, b->zero );
    a->positive = aflag_both( a->positive, b->positive );

    // These two are probably too paranoid.
    a->constant &= b->constant;
    if( !isequal_expression( a->value, b->value ) ){
	rfre_expression( a->value );
	a->value = NULL;
    }
}

// Given two abstract values, return the result if both of them occur.
void abstract_thenelse(
 AbstractValue a,
 const_AbstractValue thenval,
 const_AbstractValue elseval
)
{
    a->zero = aflag_both( a->zero, aflag_either( thenval->zero, elseval->zero ) );
    a->positive = aflag_both( a->positive, aflag_either( thenval->positive, elseval->positive ) );
    a->constant = thenval->constant & elseval->constant;

    if( a->value != NULL ){
	rfre_expression( a->value );
    }
    if( isequal_expression( thenval->value, elseval->value ) ){
	a->value = rdup_expression( thenval->value );
    }
    else {
	a->value = NULL;
    }
}

// Given a variable name, search the top program state for a
// definition of the variable.
// Return true iff the variable is found in the top program state,
// and then set '*pos' to the position of the variable in the list.
bool search_var_programstate(
 const_VarState_list vl,
 tmsymbol nm,
 unsigned int *pos
)
{
    for( unsigned int ix=0; ix<vl->sz; ix++ ){
	if( vl->arr[ix]->name == nm ){
	    *pos = ix;
	    return true;
	}
    }
    return false;
}

// Given a variable name, search the program states for a
// definition of the variable.
// Return true iff the variable is found in any of the program states,
// and then set '*lvl' to the index of the program state, and '*pos' to
// the position of the variable in the list of that program state.
bool search_var_programstates(
 const_ProgramState_list pl,
 unsigned int toplvl,
 tmsymbol nm,
 unsigned int *lvl,
 unsigned int *pos
)
{
    unsigned int ix=toplvl+1;

    if( ix>pl->sz ){
	ix = pl->sz;
    }
    while( ix>0 ){
	ix--;
	if( search_var_programstate( pl->arr[ix]->varStates, nm, pos ) ){
	    *lvl = ix;
	    return true;
	}
    }
    if( trace_analysis ){
	fprintf( stderr, "Variable '%s' not found in program state\n", nm->name );
    }
    return false;
}


// Given an expression 'x', return true if the expression is trivial
// in an initialization expression.
bool is_trivial_initialization( const_expression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGByteExpression:
	case TAGShortExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGFloatExpression:
	case TAGDoubleExpression:
	case TAGCharExpression:
	case TAGBooleanExpression:
	case TAGNullExpression:
	case TAGTypeExpression:
	case TAGDefaultValueExpression:
	case TAGSizeofExpression:
	case TAGClassIdExpression:
	    res = true;
	    break;

	case TAGComplexExpression:
	    res = is_trivial_initialization( to_const_ComplexExpression(x)->re )
	     && is_trivial_initialization( to_const_ComplexExpression(x)->im );
	    break;

	case TAGVectorExpression:
	{
	    const_expression_list xl = to_const_VectorExpression(x)->fields;

	    res = true;
	    for( unsigned int ix=0; ix<xl->sz; ix++ ){
		if( !is_trivial_initialization( xl->arr[ix] ) ){
		    res = false;
		    break;
		}
	    }
	    break;
	}

	case TAGUnopExpression:
	    res = is_trivial_initialization( to_const_UnopExpression(x)->operand );
	    break;

	case TAGAnnotationExpression:
	    res = is_trivial_initialization( to_const_AnnotationExpression(x)->x );
	    break;

	case TAGIfExpression:
	    res =
	     is_trivial_initialization( to_const_IfExpression(x)->cond ) &&
	     is_trivial_initialization( to_const_IfExpression(x)->thenval ) &&
	     is_trivial_initialization( to_const_IfExpression(x)->elseval );
	    break;

	case TAGBinopExpression:
	    res =
	     is_trivial_initialization( to_const_BinopExpression(x)->left ) &&
	     is_trivial_initialization( to_const_BinopExpression(x)->right );
	    break;

	case TAGCastExpression:
	{
	    const_type t = to_const_CastExpression(x)->t;

	    if(
		t->tag == TAGPrimitiveType &&
		to_const_PrimitiveType(t)->base != BT_STRING
	    ){
		res = is_trivial_initialization(
		    to_const_CastExpression(x)->x
		);
	    }
	    else {
		res = false;
	    }
	    break;
	}

	case TAGForcedCastExpression:
	{
	    const_type t = to_const_ForcedCastExpression(x)->t;

	    if(
		t->tag == TAGPrimitiveType &&
		to_const_PrimitiveType(t)->base != BT_STRING
	    ){
		res = is_trivial_initialization(
		    to_const_ForcedCastExpression(x)->x
		);
	    }
	    else {
		res = false;
	    }
	    break;
	}

	case TAGTypeInstanceOfExpression:
	    res = true;
	    break;

	case TAGInstanceOfExpression:
	    res = is_trivial_initialization( to_const_InstanceOfExpression(x)->x );
	    break;

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGClassExpression:
	case TAGClassInstanceOfExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldExpression:
	case TAGFieldInvocationExpression:
	case TAGGetBufExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGNotNullAssertExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGStringExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeInvocationExpression:
	case TAGVariableNameExpression:
	case TAGVectorSubscriptExpression:
	case TAGWhereExpression:
	    res = false;
	    break;

#if 0
	default:
	    break;
#endif
    }
    return res;
}

bool is_trivial_initialization( const_optexpression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGOptExprNone:
	    res = false;
	    break;

	case TAGOptExpr:
	    res = is_trivial_initialization( to_const_OptExpr( x )->x );
	    break;
    }
    return res;
}

// Given an expression 'x', return true iff the expression is the default
// initialization expression.
bool is_default_initialization( const_expression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGByteExpression:
	    res = to_const_ByteExpression(x)->v == 0;
	    break;

	case TAGShortExpression:
	    res = to_const_ShortExpression(x)->v == 0;
	    break;

	case TAGIntExpression:
	    res = to_const_IntExpression(x)->v == 0;
	    break;

	case TAGLongExpression:
	    res = to_const_LongExpression(x)->v == 0;
	    break;

	case TAGFloatExpression:
	{
	    tmstring v = to_const_FloatExpression(x)->v;

	    res = (strcmp( v, "0" ) == 0) || (strcmp( v, "0.0" ) == 0);
	    break;
	}

	case TAGDoubleExpression:
	{
	    tmstring v = to_const_DoubleExpression(x)->v;

	    res = (strcmp( v, "0" ) == 0) || (strcmp( v, "0.0" ) == 0);
	    break;
	}

	case TAGCharExpression:
	    res = to_const_CharExpression(x)->c == 0;
	    break;

	case TAGBooleanExpression:
	    res = to_const_BooleanExpression(x)->b == false;
	    break;

	case TAGNullExpression:
	case TAGDefaultValueExpression:
	    res = true;
	    break;

	case TAGTypeExpression:
	case TAGClassIdExpression:
	    res = false;
	    break;

	case TAGComplexExpression:
	    res = is_default_initialization( to_const_ComplexExpression(x)->re )
	     && is_default_initialization( to_const_ComplexExpression(x)->im );
	    break;

	case TAGVectorExpression:
	{
	    const_expression_list xl = to_const_VectorExpression(x)->fields;

	    res = true;
	    for( unsigned int ix=0; ix<xl->sz; ix++ ){
		if( !is_default_initialization( xl->arr[ix] ) ){
		    res = false;
		    break;
		}
	    }
	    break;
	}

	case TAGUnopExpression:
	    // TODO: this is not entirely correct.
	    res = false;
	    break;

	case TAGAnnotationExpression:
	    res = is_default_initialization( to_const_AnnotationExpression(x)->x );
	    break;

	case TAGIfExpression:
	    res =
	     is_default_initialization( to_const_IfExpression(x)->thenval ) &&
	     is_default_initialization( to_const_IfExpression(x)->elseval );
	    break;

	case TAGBinopExpression:
	    res = false;
	    break;

	case TAGCastExpression:
	    res = is_default_initialization( to_const_CastExpression(x)->x );
	    break;

	case TAGForcedCastExpression:
	    res = is_default_initialization( to_const_ForcedCastExpression(x)->x );
	    break;

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGClassExpression:
	case TAGClassInstanceOfExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldExpression:
	case TAGFieldInvocationExpression:
	case TAGGetBufExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGNotNullAssertExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGSizeofExpression:
	case TAGStringExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeInstanceOfExpression:
	case TAGTypeInvocationExpression:
	case TAGVariableNameExpression:
	case TAGVectorSubscriptExpression:
	case TAGWhereExpression:
	    res = false;
	    break;

    }
    return res;
}

// Given an operator 'op', return true iff it is an operator that
// is allowed in compile-time constants according to JLS2 15.28
bool is_compiletime_constant_operator( BINOP op )
{
    switch( op ){
	case BINOP_TIMES:
	case BINOP_DIVIDE:
	case BINOP_MOD:

	case BINOP_PLUS:
	case BINOP_MINUS:

	case BINOP_SHIFTRIGHT:
	case BINOP_USHIFTRIGHT:
	case BINOP_SHIFTLEFT:

	case BINOP_LESS:
	case BINOP_LESSEQUAL:
	case BINOP_GREATER:
	case BINOP_GREATEREQUAL:

	case BINOP_EQUAL:
	case BINOP_NOTEQUAL:

	case BINOP_AND:
	case BINOP_OR:
	case BINOP_XOR:

	case BINOP_SHORTAND:
	case BINOP_SHORTOR:
	    return true;
    }
    return false;
}

// Given an expression 'x', return true if the expression is a
// compile-time constant according to JLS2 15.28.
bool is_compiletime_constant( const_expression x )
{
    bool res = false;
    switch( x->tag ){
	case TAGByteExpression:
	case TAGShortExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGFloatExpression:
	case TAGDoubleExpression:
	case TAGCharExpression:
	case TAGBooleanExpression:
	case TAGNullExpression:
	case TAGTypeExpression:
	case TAGDefaultValueExpression:
	case TAGSizeofExpression:
	    res = true;
	    break;

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGClassExpression:
	case TAGClassIdExpression:
	case TAGClassInstanceOfExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldInvocationExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGGetBufExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGStringExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeInstanceOfExpression:
	case TAGTypeInvocationExpression:
	case TAGVariableNameExpression:
	case TAGVectorExpression:
	case TAGVectorSubscriptExpression:
	case TAGWhereExpression:
	    res = false;
	    break;

	case TAGNotNullAssertExpression:
	{
	    const_NotNullAssertExpression cx = to_const_NotNullAssertExpression( x );
	    res = is_compiletime_constant( cx->x );
	    break;
	}

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_compiletime_constant( cx->x );
	    break;
	}

	// Unfortunately, this one is impossible to handle, since
	// if it is here, we may not know its binding (or it would
	// have been replaced by the constant expression, or it isn't).
	case TAGFieldExpression:
	    res = false;
	    break;


	// TODO: implement this correctly
	case TAGForcedCastExpression:
	case TAGCastExpression:
	    res = false;
	    break;

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = is_compiletime_constant( cx->re ) &&
		is_compiletime_constant( cx->im );
	    break;
	}

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = is_compiletime_constant( cx->cond ) &&
		is_compiletime_constant( cx->thenval ) &&
		is_compiletime_constant( cx->elseval );
	    break;
	}

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = is_compiletime_constant( cx->operand );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    if( is_compiletime_constant_operator( cx->optor ) ){
		res = is_compiletime_constant( cx->left ) &&
		    is_compiletime_constant( cx->right );
	    }
	    else {
		res = false;
	    }
	    break;
	}

    }
    return res;
}

// Given an expression 'x', return true if the expression is a
// compile-time constant according to JLS2 15.28.
bool is_compiletime_constant( const_optexpression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGOptExprNone:
	    res = false;
	    break;

	case TAGOptExpr:
	    res = is_compiletime_constant( to_const_OptExpr( x )->x );
	    break;
    }
    return res;
}

static bool maybe_has_sideeffect( const_ActualDim_list dl, int flags );

// Given an expression, return true if it may have a side-effect.
bool maybe_has_sideeffect( const_expression x, int flags )
{
    bool res = true;

    if( x == expressionNIL ){
	return res;
    }
    switch( x->tag ){
	case TAGBooleanExpression:
	case TAGByteExpression:
	case TAGCharExpression:
	case TAGClassIdExpression:
	case TAGDoubleExpression:
	case TAGFloatExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGNullExpression:
	case TAGShortExpression:
	case TAGStringExpression:
	case TAGSuperFieldExpression:
	case TAGOuterSuperFieldExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeExpression:
	case TAGDefaultValueExpression:
	case TAGSizeofExpression:
	    res = false;
	    break;

	case TAGMethodInvocationExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldInvocationExpression:
	case TAGSuperInvocationExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeInvocationExpression:
	case TAGAssignOpExpression:
	case TAGPostIncrementExpression:
	case TAGPostDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGNewInnerClassExpression:
	    res = true;
	    break;


	case TAGNewArrayExpression:
	    if( has_any_flag( flags, NO_SE_ARRAY_NEW|NO_SE_NEW ) ){
		res = maybe_has_sideeffect( to_const_NewArrayExpression(x)->sizes, flags )
		    || maybe_has_sideeffect( to_const_NewArrayExpression(x)->initval, flags );
	    }
	    else {
		res = true;
	    }
	    break;

	case TAGNewRecordExpression:
	    res = !has_any_flag( flags, NO_SE_NEW );
	    break;

	case TAGNewClassExpression:
	    if( has_any_flag( flags, NO_SE_NEW ) ){
		res = maybe_has_sideeffect( to_const_NewClassExpression(x)->parameters, flags );
	    }
	    else {
		res = true;
	    }
	    break;

	case TAGArrayInitExpression:
	    res = maybe_has_sideeffect( to_const_ArrayInitExpression(x)->elements, flags );
	    break;

	case TAGNewInitArrayExpression:
	    if( has_any_flag( flags, NO_SE_ARRAY_NEW|NO_SE_NEW ) ){
		res = maybe_has_sideeffect( to_const_NewInitArrayExpression(x)->init, flags );
	    }
	    else {
		res = true;
	    }
	    break;

	// Unfortunately, a variable name reference may have a static
	// init as sideeffect, so we have to be careful.
	case TAGVariableNameExpression:
	{
	    varflags vflags = to_const_VariableNameExpression(x)->flags;

	    if(
		has_any_flag( flags, NO_SE_CLASSINIT ) ||
		vflags & (VAR_LOCAL|VAR_FORMAL|VAR_DYNFIELD|VAR_GLOBAL)
	    ){
		res = false;
	    }
	    else {
		res = is_qualified_origsymbol( to_const_VariableNameExpression(x)->name );
	    }
	    break;
	}

	case TAGCastExpression:
	{
	    const_CastExpression cx = to_const_CastExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = maybe_has_sideeffect( cx->re, flags ) ||
		maybe_has_sideeffect( cx->im, flags );
	    break;
	}

	case TAGVectorExpression:
	    res = maybe_has_sideeffect( to_const_VectorExpression( x )->fields, flags );
	    break;

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = maybe_has_sideeffect( cx->cond, flags ) ||
		maybe_has_sideeffect( cx->thenval, flags )||
		maybe_has_sideeffect( cx->elseval, flags );
	    break;
	}

	case TAGWhereExpression:
	    // TODO: look at this more closely.
	    res = true;
	    break;

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = maybe_has_sideeffect( cx->operand, flags );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    res = maybe_has_sideeffect( cx->left, flags ) ||
		maybe_has_sideeffect( cx->right, flags );
	    break;
	}

	case TAGInstanceOfExpression:
	{
	    const_InstanceOfExpression cx = to_const_InstanceOfExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

	case TAGInterfaceInstanceOfExpression:
	{
	    const_InterfaceInstanceOfExpression cx = to_const_InterfaceInstanceOfExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

	case TAGTypeInstanceOfExpression:
	    res = false;
	    break;

	case TAGClassInstanceOfExpression:
	{
	    const_ClassInstanceOfExpression cx = to_const_ClassInstanceOfExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

	case TAGGetSizeExpression:
	{
	    const_GetSizeExpression cx = to_const_GetSizeExpression( x );
	    res = maybe_has_sideeffect( cx->array, flags ) ||
		maybe_has_sideeffect( cx->dim, flags );
	    break;
	}

	case TAGGetBufExpression:
	{
	    const_GetBufExpression cx = to_const_GetBufExpression( x );
	    res = maybe_has_sideeffect( cx->array, flags );
	    break;
	}

	case TAGGetLengthExpression:
	{
	    const_GetLengthExpression cx = to_const_GetLengthExpression( x );
	    res = maybe_has_sideeffect( cx->array, flags );
	    break;
	}

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

	case TAGVectorSubscriptExpression:
	{
	    const_VectorSubscriptExpression cx = to_const_VectorSubscriptExpression( x );
	    res = maybe_has_sideeffect( cx->vector, flags );
	    break;
	}

	case TAGSubscriptExpression:
	{
	    const_SubscriptExpression cx = to_const_SubscriptExpression( x );
	    res = maybe_has_sideeffect( cx->array, flags ) ||
		maybe_has_sideeffect( cx->subscripts, flags );
	    break;
	}

	// Unfortunately, this may have a static
	// init as sideeffect, so..
	case TAGFieldExpression:
	    if(
		has_any_flag( flags, NO_SE_CLASSINIT ) &&
		has_any_flag( flags, NO_SE_EXCEPTION|NO_SE_NULLPOINTER )
	    ){
		res = maybe_has_sideeffect( to_const_FieldExpression(x)->rec, flags );
	    }
	    else {
		res = true;
	    }
	    break;

	case TAGNotNullAssertExpression:
	    // We consider an assert a sideeffect.
	    res = true;
	    break;

	case TAGClassExpression:
	    res = true;
	    break;

	case TAGForcedCastExpression:
	{
	    const_ForcedCastExpression cx = to_const_ForcedCastExpression( x );
	    res = maybe_has_sideeffect( cx->x, flags );
	    break;
	}

    }
    return res;
}

// Given a list of expressions, return true if one of the expressions
// may have a side-effect.
bool maybe_has_sideeffect( const_expression_list xl, int flags )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( maybe_has_sideeffect( xl->arr[ix], flags ) ){
	    return true;
	}
    }
    return false;
}

static bool maybe_has_sideeffect( const_ActualDim_list dl, int flags )
{
    for( unsigned int ix=0; ix<dl->sz; ix++ ){
	const_ActualDim d = dl->arr[ix];
	if( maybe_has_sideeffect( d->vector, flags ) ){
	    return true;
	}
    }
    return false;
}

// Given an optional expression, return true if it may have  side-effect.
bool maybe_has_sideeffect( const_optexpression x, int flags )
{
    bool res = false;

    switch( x->tag ){
	case TAGOptExpr:
	    res =  maybe_has_sideeffect( to_const_OptExpr(x)->x, flags );
	    break;

	case TAGOptExprNone:
	    res = false;
	    break;
    }
    return res;
}

// Given an expression, return 'true' if the expression is certain to
// be constant.
bool is_constant( const_expression x )
{
    bool res = false;

    if( x == expressionNIL ){
	return res;
    }
    switch( x->tag ){
	case TAGBooleanExpression:
	case TAGByteExpression:
	case TAGCharExpression:
	case TAGClassIdExpression:
	case TAGDoubleExpression:
	case TAGFloatExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGNullExpression:
	case TAGShortExpression:
	case TAGStringExpression:
	case TAGTypeExpression:
	case TAGDefaultValueExpression:
	case TAGSizeofExpression:
	case TAGTypeInstanceOfExpression:
	    res = true;
	    break;

	case TAGArrayInitExpression:
	case TAGGetBufExpression:
	case TAGAssignOpExpression:
	case TAGClassInstanceOfExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldInvocationExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGSuperFieldExpression:
	case TAGOuterSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeInvocationExpression:
	case TAGVariableNameExpression:
	    res = false;
	    break;

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = is_constant( cx->re ) && is_constant( cx->im );
	    break;
	}

	case TAGVectorExpression:
	    res = is_constant( to_const_VectorExpression( x )->fields );
	    break;

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = is_constant( cx->cond ) &&
		is_constant( cx->thenval ) &&
		is_constant( cx->elseval );
	    break;
	}

	case TAGWhereExpression:
	    // TODO: look at the expression more closely.
	    res = false;
	    break;

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = is_constant( cx->operand );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    res = is_constant( cx->left ) && is_constant( cx->right );
	    break;
	}

	case TAGGetSizeExpression:
	{
	    const_GetSizeExpression cx = to_const_GetSizeExpression( x );
	    res = is_constant( cx->array ) && is_constant( cx->dim );
	    break;
	}

	case TAGGetLengthExpression:
	{
	    const_GetLengthExpression cx = to_const_GetLengthExpression( x );
	    res = is_constant( cx->array );
	    break;
	}

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_constant( cx->x );
	    break;
	}

	case TAGVectorSubscriptExpression:
	{
	    const_VectorSubscriptExpression cx = to_const_VectorSubscriptExpression( x );
	    res = is_constant( cx->vector );
	    break;
	}

	case TAGSubscriptExpression:
	{
	    const_SubscriptExpression cx = to_const_SubscriptExpression( x );
	    res = is_constant( cx->array ) && is_constant( cx->subscripts );
	    break;
	}

	case TAGFieldExpression:
	{
	    const_FieldExpression cx = to_const_FieldExpression( x );
	    res = is_constant( cx->rec );
	    break;
	}

	case TAGClassExpression:
	    res = true;
	    break;

	case TAGNotNullAssertExpression:
	{
	    const_NotNullAssertExpression cx = to_const_NotNullAssertExpression( x );
	    res = is_constant( cx->x );
	    break;
	}

	case TAGCastExpression:
	{
	    const_CastExpression cx = to_const_CastExpression( x );
	    res = is_constant( cx->x );
	    break;
	}

	case TAGForcedCastExpression:
	{
	    const_ForcedCastExpression cx = to_const_ForcedCastExpression( x );
	    res = is_constant( cx->x );
	    break;
	}

    }
    return res;
}

// Given a list of expressions, return true if one of the expressions
// may have a side-effect.
bool is_constant( const_expression_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( !is_constant( xl->arr[ix] ) ){
	    return false;
	}
    }
    return true;
}

// Given an expression, return 'true' if the expression is certain to
// be constant.
bool is_inlinable_actual( const_expression x )
{
    bool res = false;

    if( x == expressionNIL ){
	return res;
    }
    switch( x->tag ){
	case TAGBooleanExpression:
	case TAGByteExpression:
	case TAGCharExpression:
	case TAGClassIdExpression:
	case TAGDefaultValueExpression:
	case TAGDoubleExpression:
	case TAGFloatExpression:
	case TAGGetBufExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGNullExpression:
	case TAGShortExpression:
	case TAGSizeofExpression:
	case TAGStringExpression:
	case TAGTypeExpression:
	case TAGTypeFieldExpression:
	case TAGOuterThisExpression:
	case TAGTypeInstanceOfExpression:
	case TAGVariableNameExpression:
	    res = true;
	    break;

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldInvocationExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGMethodInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGSuperFieldExpression:
	case TAGOuterSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeInvocationExpression:
	    res = false;
	    break;

	case TAGClassInstanceOfExpression:
	{
	    const_ClassInstanceOfExpression ix = to_const_ClassInstanceOfExpression(x);
	    res = is_inlinable_actual( ix->x );
	}

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = is_inlinable_actual( cx->re ) && is_inlinable_actual( cx->im );
	    break;
	}

	case TAGVectorExpression:
	    res = is_inlinable_actual( to_const_VectorExpression( x )->fields );
	    break;

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = is_inlinable_actual( cx->cond ) &&
		is_inlinable_actual( cx->thenval ) &&
		is_inlinable_actual( cx->elseval );
	    break;
	}

	case TAGWhereExpression:
	    // TODO: look at the expression more closely.
	    res = false;
	    break;

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = is_inlinable_actual( cx->operand );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    res = is_inlinable_actual( cx->left ) && is_inlinable_actual( cx->right );
	    break;
	}

	case TAGGetSizeExpression:
	{
	    const_GetSizeExpression cx = to_const_GetSizeExpression( x );
	    res = is_inlinable_actual( cx->array ) && is_inlinable_actual( cx->dim );
	    break;
	}

	case TAGGetLengthExpression:
	{
	    const_GetLengthExpression cx = to_const_GetLengthExpression( x );
	    res = is_inlinable_actual( cx->array );
	    break;
	}

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_inlinable_actual( cx->x );
	    break;
	}

	case TAGVectorSubscriptExpression:
	{
	    const_VectorSubscriptExpression cx = to_const_VectorSubscriptExpression( x );
	    res = is_inlinable_actual( cx->vector );
	    break;
	}

	case TAGSubscriptExpression:
	{
	    const_SubscriptExpression cx = to_const_SubscriptExpression( x );
	    res = is_inlinable_actual( cx->array ) && is_inlinable_actual( cx->subscripts );
	    break;
	}

	case TAGFieldExpression:
	{
	    const_FieldExpression cx = to_const_FieldExpression( x );
	    res = is_inlinable_actual( cx->rec );
	    break;
	}

	case TAGClassExpression:
	    res = true;
	    break;

	case TAGNotNullAssertExpression:
	{
	    const_NotNullAssertExpression cx = to_const_NotNullAssertExpression( x );
	    res = is_inlinable_actual( cx->x );
	    break;
	}

	case TAGCastExpression:
	{
	    const_CastExpression cx = to_const_CastExpression( x );
	    res = is_inlinable_actual( cx->x );
	    break;
	}

	case TAGForcedCastExpression:
	{
	    const_ForcedCastExpression cx = to_const_ForcedCastExpression( x );
	    res = is_inlinable_actual( cx->x );
	    break;
	}

    }
    return res;
}

// Given a list of expressions, return true if one of the expressions
// may have a side-effect.
bool is_inlinable_actual( const_expression_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( !is_inlinable_actual( xl->arr[ix] ) ){
	    return false;
	}
    }
    return true;
}

// Given an expression 'x', try to determine if the expression evaluates
// to zero/null/false. Possible answers are yes, no, or maybe.
AFLAG is_zero( const_expression x, const_ProgramState_list state )
{
    AFLAG res = AF_MAYBE;

    switch( x->tag ){
	case TAGArrayInitExpression:
	case TAGConstructorInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGStringExpression:
	case TAGTypeExpression:
	case TAGSizeofExpression:
	case TAGGetBufExpression:
	    res = AF_NO;
	    break;

	// TODO: take a look at the actual constant.
	case TAGClassExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGInstanceOfExpression:
	case TAGInterfaceInstanceOfExpression:
	    res = AF_MAYBE;
	    break;

	case TAGComplexExpression:
	{
	    AFLAG re_val = is_zero( to_const_ComplexExpression(x)->re, state );
	    AFLAG im_val = is_zero( to_const_ComplexExpression(x)->im, state );
	    res = AF_MAYBE;
	    if( re_val == AF_YES && im_val == AF_YES ){
		res = AF_YES;
	    }
	    else if( re_val == AF_NO || im_val == AF_NO ){
		res = AF_NO;
	    }
	    break;
	}

	case TAGDoubleExpression:
	{
	    tmstring v = to_const_DoubleExpression(x)->v;
	    res = AF_MAYBE;

	    // TODO: be smarter than this. It must be possible to say 'no'
	    // in some cases.
	    if( (strcmp( v, "0" ) == 0) || (strcmp( v, "0.0" ) == 0) ){
		res = AF_YES;
	    }
	    break;
	}

	case TAGFloatExpression:
	{
	    tmstring v = to_const_FloatExpression(x)->v;
	    res = AF_MAYBE;

	    // TODO: be smarter than this. It must be possible to say 'no'
	    // in some cases.
	    if( (strcmp( v, "0" ) == 0) || (strcmp( v, "0.0" ) == 0) ){
		res = AF_YES;
	    }
	    break;
	}

	case TAGLongExpression:
	{
	    vnus_long v = to_const_LongExpression(x)->v;
	    res = v == 0?AF_YES:AF_NO;
	    break;
	}

	case TAGShortExpression:
	{
	    vnus_short v = to_const_ShortExpression(x)->v;
	    res = v == 0?AF_YES:AF_NO;
	    break;
	}

	case TAGCharExpression:
	{
	    vnus_char c = to_const_CharExpression(x)->c;
	    res = c == 0?AF_YES:AF_NO;
	    break;
	}

	case TAGIntExpression:
	{
	    vnus_int v = to_const_IntExpression(x)->v;
	    res = v == 0?AF_YES:AF_NO;
	    break;
	}

	case TAGByteExpression:
	{
	    vnus_byte v = to_const_ByteExpression(x)->v;
	    res = (v == 0)?AF_YES:AF_NO;
	    break;
	}

	case TAGBooleanExpression:
	{
	    vnus_boolean b = to_const_BooleanExpression(x)->b;
	    res = b?AF_YES:AF_NO;
	    break;
	}

	case TAGBinopExpression:
	case TAGClassIdExpression:
	case TAGClassInstanceOfExpression:
	case TAGFieldExpression:
	case TAGFieldInvocationExpression:
	case TAGMethodInvocationExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGTypeInstanceOfExpression:
	case TAGTypeInvocationExpression:
	case TAGUnopExpression:
	case TAGVectorExpression:
	    res = AF_MAYBE;
	    break;

	case TAGOuterThisExpression:
	    // A 'this' expression cannot be null.
	    res = AF_NO;
	    break;

	case TAGVariableNameExpression:
	{
	    unsigned int lvl;
	    unsigned int pos;
	    tmsymbol nm = to_const_VariableNameExpression(x)->name->sym;

	    if(  search_var_programstates( state, state->sz, nm, &lvl, &pos ) ){
		VarState v = state->arr[lvl]->varStates->arr[pos];
		bool maybe_overwritten = false;

		if( !v->final ){
		    // See wether there are any iterations between our level
		    // and the level where the variable state is registered.
		    // We don't care wether the level of the variable is an
		    // iteration, since if so, the state change was caused
		    // within the iteration.
		    for( unsigned int ix=lvl+1; ix<state->sz; ix++ ){
			if( state->arr[ix]->iterated ){
			    maybe_overwritten = true;
			    break;
			}
		    }
		}
		if( maybe_overwritten ){
		    res = AF_MAYBE;
		}
		else {
		    res = v->value->zero;
		}
	    }
	    else {
		res = AF_MAYBE;
	    }
	    break;
	}

	case TAGNullExpression:
	    res = AF_YES;
	    break;

	case TAGDefaultValueExpression:
	    res = AF_YES;
	    break;

	case TAGVectorSubscriptExpression:
	    res = is_zero( to_const_VectorSubscriptExpression(x)->vector, state );
	    break;

	case TAGAssignOpExpression:
	    res = is_zero( to_const_AssignOpExpression(x)->right, state );
	    break;

	case TAGIfExpression:
	{
	    // TODO: be smarter about constant conditions.
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = aflag_either( is_zero( cx->thenval, state ), is_zero( cx->elseval, state ) );
	    break;
	}

	case TAGWhereExpression:
	    // TODO: look at the expression more closely.
	    res = AF_MAYBE;
	    break;

	case TAGAnnotationExpression:
	{
	    // TODO: support an annotation that says yes or no here.
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_zero( cx->x, state );
	    break;
	}

	// An expression with a null assert can only evaluate to not-null.
	case TAGNotNullAssertExpression:
	    res = AF_NO;
	    break;

	case TAGCastExpression:
	{
	    const_CastExpression cx = to_const_CastExpression( x );
	    res = is_zero( cx->x, state );
	    break;
	}

	case TAGForcedCastExpression:
	{
	    const_ForcedCastExpression cx = to_const_ForcedCastExpression( x );
	    res = is_zero( cx->x, state );
	    break;
	}

    }
    return res;
}

// Given an expression 'x', return the abstract evaluation of it.
AbstractValue abstract_value( const_expression x, const_ProgramState_list state )
{
    AbstractValue res = AbstractValueNIL;

    if( x == expressionNIL ){
	return new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
    }
    switch( x->tag ){
	case TAGBinopExpression:	// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGBooleanExpression:
	{
	    vnus_boolean b = to_const_BooleanExpression(x)->b;
	    if( b ){
		// True is not zero
		res = new_AbstractValue( AF_NO, AF_YES, true, rdup_expression( x ) );
	    }
	    else {
		// False is zero
		res = new_AbstractValue( AF_YES, AF_YES, true, rdup_expression( x ) );
	    }
	    break;
	}

	case TAGByteExpression:
	{
	    vnus_byte v = to_const_ByteExpression(x)->v;
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue(
		v==0?AF_YES:AF_NO,
		v>=0?AF_YES:AF_NO,
		true,
		rdup_expression( x )
	    );
	    break;
	}

	case TAGCharExpression:		// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGClassExpression:
	    // Maybe zero, maybe positive.
	    // NOTE: once we return a proper class for the 
	    // primitive types, we know that this can never return null.
	    res = new_AbstractValue( AF_MAYBE, AF_YES, true, NULL );
	    break;

	case TAGClassIdExpression:
	    // Maybe zero, must be positive.
	    res = new_AbstractValue( AF_MAYBE, AF_YES, true, NULL );
	    break;

	case TAGClassInstanceOfExpression:	// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGComplexExpression:	// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGDoubleExpression:	// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGFloatExpression:	// No check on positive
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGGetBufExpression:
	    // Not zero, positive.
	    res = new_AbstractValue( AF_NO, AF_YES, true, NULL );
	    break;
	    
	case TAGGetSizeExpression:
	case TAGGetLengthExpression:
	    // Maybe zero, must be positive.
	    res = new_AbstractValue( AF_MAYBE, AF_YES, true, NULL );
	    break;

	case TAGInstanceOfExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGTypeInstanceOfExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGIntExpression:
	{
	    vnus_int v = to_const_IntExpression(x)->v;
	    res = new_AbstractValue( v==0?AF_YES:AF_NO, v>=0?AF_YES:AF_NO, true, rdup_expression( x ) );
	    break;
	}

	case TAGInterfaceInstanceOfExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGLongExpression:
	{
	    vnus_long v = to_const_LongExpression(x)->v;
	    res = new_AbstractValue( v==0?AF_YES:AF_NO, v>=0?AF_YES:AF_NO, true, rdup_expression( x ) );
	    break;
	}

	case TAGPostDecrementExpression:
	case TAGPostIncrementExpression:
	case TAGPreDecrementExpression:
	case TAGPreIncrementExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGShortExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGStringExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_YES, true, NULL );
	    break;

	case TAGTypeExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, true, NULL );
	    break;

	case TAGUnopExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGVectorExpression:
	    // Maybe zero, maybe positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGArrayInitExpression:
	case TAGConstructorInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	    // Not zero, positive.
	    res = new_AbstractValue( AF_NO, AF_YES, true, NULL );
	    break;

	case TAGFieldExpression:
	case TAGFieldInvocationExpression:
	case TAGSubscriptExpression:
	case TAGSuperFieldExpression:
	case TAGOuterSuperFieldExpression:
	case TAGSuperInvocationExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeFieldExpression:
	case TAGTypeInvocationExpression:
	    // Perhaps zero, perhaps positive.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGOuterThisExpression:
	    // A 'this' expression cannot be null
	    res = new_AbstractValue( AF_NO, AF_YES, true, NULL );
	    break;

	case TAGMethodInvocationExpression:
	{
	    const_MethodInvocation call = to_const_MethodInvocationExpression(x)->invocation;
	    if( has_any_flag( call->flags, CALL_CONSTRUCTOR ) ){
		// Not zero, positive.
		res = new_AbstractValue( AF_NO, AF_YES, true, NULL );
	    }
	    else {
		// Perhaps zero, perhaps positive.
		res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    }
	    break;
	}

	case TAGVariableNameExpression:		// No check on positive
	{
	    unsigned int lvl;
	    unsigned int pos;
	    tmsymbol nm = to_const_VariableNameExpression(x)->name->sym;

	    if(  search_var_programstates( state, state->sz, nm, &lvl, &pos ) ){
		VarState v = state->arr[lvl]->varStates->arr[pos];
		bool iterated = false;

		if( !v->final ){
		    for( unsigned int ix=lvl; ix<state->sz; ix++ ){
			if( state->arr[ix]->iterated ){
			    iterated = true;
			    break;
			}
		    }
		}
		if( iterated ){
		    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
		}
		else {
		    res = rdup_AbstractValue( v->value );
		}
	    }
	    else {
		res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    }
	    if( has_any_flag( to_const_VariableNameExpression(x)->flags, VAR_THIS ) ){
		// This is a 'this' variable. We know it can never be zero.
		res->zero = AF_NO;
		res->positive = AF_YES;
	    }
	    break;
	}

	case TAGSizeofExpression:
	    // Not zero, positive
	    res = new_AbstractValue(
		AF_NO,		// Zero
		AF_YES,		// Positive
		true,		// constant
		rdup_expression( x )
	    );
	    break;

	case TAGNullExpression:
	    // Zero, positive
	    res = new_AbstractValue(
		AF_YES,		// Zero
		AF_YES,		// Positive
		true,		// constant
		rdup_expression( x )
	    );
	    break;

	case TAGDefaultValueExpression:
	    // Zero, positive
	    res = new_AbstractValue(
		AF_YES,
		AF_YES,
		true,
		NULL
	    );
	    break;

	case TAGVectorSubscriptExpression:
	    // Perhaps zero, perhaps positive.
	    // TODO: be smarter about this.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGAssignOpExpression:
	    res = abstract_value( to_const_AssignOpExpression(x)->right, state );
	    break;

	case TAGIfExpression:
	{
	    // TODO: be smarter about constant conditions.
	    const_IfExpression cx = to_const_IfExpression( x );
	    AbstractValue thenval = abstract_value( cx->thenval, state );
	    AbstractValue elseval = abstract_value( cx->elseval, state );
	    abstract_either( thenval, elseval );
	    res = thenval;
	    rfre_AbstractValue( elseval );
	    break;
	}

	case TAGWhereExpression:
	    // TODO: look at the expression more closely.
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, false, NULL );
	    break;

	case TAGAnnotationExpression:
	{
	    // TODO: support an annotation that says yes or no here.
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = abstract_value( cx->x, state );
	    break;
	}

	// An expression with a null assert can only evaluate to not-null.
	case TAGNotNullAssertExpression:
	    res = new_AbstractValue( AF_NO, AF_MAYBE, false, NULL );
	    break;

	case TAGCastExpression:
	{
	    // TODO: be less paranoid when you can be. We only say
	    // perhaps because a narrowing conversion could alter the
	    // number of bits that are relevant, and hence the abstract
	    // value.
	    AbstractValue castval = abstract_value(
		to_const_CastExpression(x)->x,
		state
	    );
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, castval->constant, NULL );
	    if( castval->zero == AF_YES ){
		res->zero = AF_YES;
		res->positive = AF_YES;
		if(
		    castval->value != NULL &&
		    castval->value->tag == TAGNullExpression
		){
		    res->value = castval->value;
		    castval->value = NULL;
		}
	    }
	    rfre_AbstractValue( castval );
	    break;
	}

	case TAGForcedCastExpression:
	{
	    // TODO: be less paranoid when you can be. We only say
	    // perhaps because a narrowing conversion could alter the
	    // number of bits that are relevant, and hence the abstract
	    // value.
	    AbstractValue castval = abstract_value(
		to_const_ForcedCastExpression(x)->x,
		state
	    );
	    res = new_AbstractValue( AF_MAYBE, AF_MAYBE, castval->constant, NULL );

	    if( castval->zero == AF_YES ){
		res->zero = AF_YES;
		res->positive = AF_YES;
		if(
		    castval->value != NULL &&
		    castval->value->tag == TAGNullExpression
		){
		    res->value = castval->value;
		    castval->value = NULL;
		}
	    }
	    rfre_AbstractValue( castval );
	    break;
	}

    }
    return res;
}

static void dump_AFLAG( FILE *f, char c, const AFLAG fl )
{
    fputc( c, f );
    fputc( ':', f );
    if( fl == AF_YES ){
	fputc( 'y', f );
    }
    else if( fl == AF_NO ){
	fputc( 'n', f );
    }
    else {
	fputc( '?', f );
    }
}

static void dump_VarState( FILE *f, const_VarState s )
{
    fprintf( f, "%s=A:", s->name->name );
    fputc( s->defassigned?'y':'n', f );
    fputs( " U:", f );
    fputc( s->defunassigned?'y':'n', f );
    fputc( ' ', f );
    dump_AFLAG( f, 'z', s->value->zero );
    fputc( ' ', f );
    dump_AFLAG( f, 'p', s->value->positive );
    fputc( ' ', f );
    if( s->value->constant ){
	fputc( 'c', f );
    }
    if( s->value->value != NULL ){
	fputc( 'v', f );
    }
}

static void dump_VarState_list( FILE *f, const_VarState_list sl )
{
    for( unsigned int ix=0; ix<sl->sz; ix++ ){
	if( ix != 0 ){
	    fputc( ' ', f );
	}
	dump_VarState( f, sl->arr[ix] );
    }
}

static void dump_programstate( FILE *f, unsigned int lvl, const_ProgramState st )
{
    fprintf( f, "%2d: %s", lvl, st->iterated?"(iterated) ":"" );
    dump_VarState_list( f, st->varStates );
    fputc( '\n', f );
}

void dump_programstates( FILE *f, const_ProgramState_list states )
{
    fprintf( f, "Program state is now:\n" );

    unsigned int ix = states->sz;
    while( ix>0 ){
	ix--;
	dump_programstate( f, ix, states->arr[ix] );
    }
}

// Forward declaration.
static bool is_GC_expression_list( const_Entry_list symtab, const_expression_list xl );

static bool is_GC_invocation( const_Entry_list symtab, const_MethodInvocation call )
{
    if( call->vtab != NULL ){
	// this is a virtual call. For the moment we're not going to touch that.
	return true;
    }
    const_MethodEntry e = lookup_MethodEntry( symtab, call->name->sym );
    if( e == MethodEntryNIL ){
	return true;
    }
    if( get_flag_pragma( Pragma_listNIL, e->pragmas, "noGC" ) ){
	// The invoked method does not cause a GC event, but the actual
	// parameters might still cause it...
	return is_GC_expression_list( symtab, call->parameters ) ||
	    is_GC_expression_list( symtab, call->thisparameters );
    }
    return true;
}

// Given an expression 'x', return true if the expression may have garbage
// collection as side-effect.
static bool is_GC_expression( const_Entry_list symtab, const_expression x )
{
    bool res = false;
    if( x == expressionNIL ){
	return false;
    }
    switch( x->tag ){
	case TAGBooleanExpression:
	case TAGByteExpression:
	case TAGCharExpression:
	case TAGClassIdExpression:
	case TAGDefaultValueExpression:
	case TAGDoubleExpression:
	case TAGFloatExpression:
	case TAGIntExpression:
	case TAGLongExpression:
	case TAGNullExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterThisExpression:
	case TAGShortExpression:
	case TAGSizeofExpression:
	case TAGSuperFieldExpression:
	case TAGTypeExpression:
	case TAGTypeFieldExpression:
	case TAGTypeInstanceOfExpression:
	case TAGVariableNameExpression:
	    res = false;
	    break;

	// At the point we are looking at this, string init is already
	// explicit. String constants themselves don't cause GC.
	case TAGStringExpression:
	    res = false;
	    break;

	case TAGInterfaceInstanceOfExpression:
	    res = is_GC_expression( symtab, to_const_InterfaceInstanceOfExpression(x)->x );
	    break;

	case TAGClassInstanceOfExpression:
	    res = is_GC_expression( symtab, to_const_ClassInstanceOfExpression(x)->x );
	    break;

	case TAGGetLengthExpression:
	    res = is_GC_expression( symtab, to_const_GetLengthExpression(x)->implementation );
	    break;

	case TAGGetSizeExpression:
	    res = is_GC_expression( symtab, to_const_GetSizeExpression(x)->implementation );
	    break;

	case TAGGetBufExpression:
	    res = is_GC_expression( symtab, to_const_GetBufExpression(x)->array );
	    break;

	case TAGInstanceOfExpression:
	    res = is_GC_expression( symtab, to_const_InstanceOfExpression(x)->x );
	    break;

	case TAGArrayInitExpression:
	case TAGAssignOpExpression:
	case TAGClassExpression:
	case TAGConstructorInvocationExpression:
	case TAGFieldInvocationExpression:
	case TAGNewArrayExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGNewRecordExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeInvocationExpression:
	case TAGSuperInvocationExpression:
	case TAGNotNullAssertExpression:	// Because of exception.
	    res = true;
	    break;

	case TAGMethodInvocationExpression:
	    res = is_GC_invocation( symtab, to_const_MethodInvocationExpression(x)->invocation );
	    break;

	// TODO: have a better look
	case TAGWhereExpression:
	    res = true;
	    break;

	case TAGVectorExpression:
	    res = is_GC_expression_list( symtab, to_const_VectorExpression(x)->fields );
	    break;

	case TAGSubscriptExpression:
	    if( no_boundscheck ){
		res = is_GC_expression( symtab, to_const_SubscriptExpression(x)->array )
		    || is_GC_expression( symtab, to_const_SubscriptExpression(x)->subscripts );
	    }
	    else {
		res = true;	// Because of out-of-bounds exception
	    }
	    break;

	case TAGVectorSubscriptExpression:
	    res = is_GC_expression( symtab, to_const_VectorSubscriptExpression(x)->vector );
	    break;

	case TAGFieldExpression:
	    res = is_GC_expression( symtab, to_const_FieldExpression(x)->rec );
	    break;

	case TAGPreIncrementExpression:
	    res = is_GC_expression( symtab, to_const_PreIncrementExpression(x)->x );
	    break;

	case TAGPreDecrementExpression:
	    res = is_GC_expression( symtab, to_const_PreDecrementExpression(x)->x );
	    break;

	case TAGPostIncrementExpression:
	    res = is_GC_expression( symtab, to_const_PostIncrementExpression(x)->x );
	    break;

	case TAGPostDecrementExpression:
	    res = is_GC_expression( symtab, to_const_PostDecrementExpression(x)->x );
	    break;

	case TAGForcedCastExpression:
	    res = is_GC_expression( symtab, to_const_ForcedCastExpression(x)->x );
	    break;

	case TAGCastExpression:
	    res = is_GC_expression( symtab, to_const_CastExpression(x)->x );
	    break;

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_GC_expression( symtab, cx->x );
	    break;
	}

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = is_GC_expression( symtab, cx->re ) &&
		is_GC_expression( symtab, cx->im );
	    break;
	}

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = is_GC_expression( symtab, cx->cond ) &&
		is_GC_expression( symtab, cx->thenval ) &&
		is_GC_expression( symtab, cx->elseval );
	    break;
	}

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = is_GC_expression( symtab, cx->operand );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    res = is_GC_expression( symtab, cx->left ) && is_GC_expression( symtab, cx->right );
	    break;
	}

    }
    return res;
}

// Given an optional expression 'x', return true iff the expression may have
// garbage collection as side-effect.
static bool is_GC_expression( const_Entry_list symtab, const_optexpression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGOptExpr:
	    res =  is_GC_expression( symtab, to_const_OptExpr(x)->x );
	    break;

	case TAGOptExprNone:
	    res = false;
	    break;
    }
    return res;
}

static bool is_GC_expression_list( const_Entry_list symtab, const_expression_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GC_expression( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GC_Cardinality( const_Entry_list symtab, const_Cardinality card )
{
    return is_GC_expression( symtab, card->lowerbound )
        || is_GC_expression( symtab, card->upperbound )
        || is_GC_expression( symtab, card->stride );
}

static bool is_GC_Cardinality_list( const_Entry_list symtab, const_Cardinality_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GC_Cardinality( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GC_statement_list( const_Entry_list symtab, const_statement_list xl )
{
    if( xl == statement_listNIL ){
	return false;
    }
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GC_statement( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

// Return true iff the block may do garbage collection.
static bool is_GC_Block( const_Entry_list symtab, const_Block blk )
{
    return is_GC_statement_list( symtab, blk->statements );
}

// Given a statement, return true iff it may cause garbage collection.
bool is_GC_statement( const_Entry_list symtab, const_statement smt )
{
    bool res = false;

    switch( smt->tag ){
	case TAGClassDeclaration:
	case TAGInterfaceDeclaration:
	case TAGFunctionDeclaration:
	case TAGNativeFunctionDeclaration:
	case TAGAbstractFunctionDeclaration:
	case TAGGotoStatement:
	case TAGReturnStatement:
	case TAGConstructorDeclaration:
	case TAGEmptyStatement:
	case TAGBreakStatement:
	case TAGContinueStatement:
	case TAGGCBuildRefChainLinkStatement:
	case TAGGCSetRefChainLinkStatement:
	case TAGGCSetTopRefChainLinkStatement:
	case TAGInstanceInitializer:
	    res = false;
	    break;

	case TAGBlockStatement:
	    res = is_GC_Block( symtab, to_const_BlockStatement(smt)->body );
	    break;

	case TAGEachStatement:
	    res = is_GC_statement_list( symtab, to_const_EachStatement(smt)->statements );
	    break;

	case TAGTryStatement:
	case TAGSimpleTryStatement:
	    // TODO: have a closer look
	    res = true;
	    break;

	case TAGOuterSuperInvocationStatement:
	case TAGTypeInvocationStatement:
	case TAGFieldInvocationStatement:
	case TAGSuperConstructorInvocationStatement:
	case TAGSuperInvocationStatement:
	case TAGOuterSuperConstructorInvocationStatement:
	case TAGThisConstructorInvocationStatement:
	case TAGStaticInitializer:
	    res = true;
	    break;

	case TAGMethodInvocationStatement:
	    res = is_GC_invocation( symtab, to_const_MethodInvocationStatement(smt)->invocation );
	    break;

	case TAGValueReturnStatement:
	    res = is_GC_expression( symtab, to_const_ValueReturnStatement(smt)->v );
	    break;

	case TAGInternalThrowStatement:
	    res = is_GC_expression( symtab, to_const_InternalThrowStatement(smt)->x );
	    break;

	case TAGSynchronizedStatement:
	    res = is_GC_expression( symtab, to_const_SynchronizedStatement(smt)->on ) ||
		is_GC_Block( symtab, to_const_SynchronizedStatement(smt)->body );
	    break;

	case TAGThrowStatement:
	    res = is_GC_expression( symtab, to_const_ThrowStatement(smt)->x );
	    break;

	case TAGIfStatement:
	    res = is_GC_expression( symtab, to_const_IfStatement(smt)->cond ) ||
		is_GC_Block( symtab, to_const_IfStatement(smt)->thenbody ) ||
		is_GC_Block( symtab, to_const_IfStatement(smt)->elsebody );
	    break;

	case TAGDoWhileStatement:
	    res = is_GC_expression( symtab, to_const_DoWhileStatement(smt)->cond ) ||
		is_GC_Block( symtab, to_const_DoWhileStatement(smt)->body ) ||
		is_GC_statement_list( symtab, to_const_DoWhileStatement(smt)->update );
	    break;

	case TAGWhileStatement:
	    res = is_GC_expression( symtab, to_const_WhileStatement(smt)->cond ) ||
		is_GC_Block( symtab, to_const_WhileStatement(smt)->body ) ||
		is_GC_statement_list( symtab, to_const_WhileStatement(smt)->update );
	    break;

	case TAGSwitchStatement:
	    // TODO: have a closer look.
	    //res = is_GC_expression( symtab, to_const_SwitchStatement(smt)->cond );
	    res = true;
	    break;

	case TAGExpressionStatement:
	    res = is_GC_expression( symtab, to_const_ExpressionStatement(smt)->x );
	    break;

	case TAGDeleteStatement:
	    res = is_GC_expression( symtab, to_const_DeleteStatement(smt)->adr );
	    break;

	case TAGAssignStatement:
	    res = is_GC_expression( symtab, to_const_AssignStatement(smt)->lhs )
	     || is_GC_expression( symtab, to_const_AssignStatement(smt)->rhs );
	    break;

	case TAGFieldDeclaration:
	    res = is_GC_expression( symtab, to_const_FieldDeclaration(smt)->init );
	    break;

	case TAGPrintStatement:
	    res = is_GC_expression_list( symtab, to_const_PrintStatement(smt)->argv );
	    break;

	case TAGPrintLineStatement:
	    res = is_GC_expression_list( symtab, to_const_PrintLineStatement(smt)->argv );
	    break;

	case TAGForStatement:
	    res = is_GC_Cardinality_list( symtab, to_const_ForStatement(smt)->cards ) ||
		is_GC_Block( symtab, to_const_ForStatement(smt)->body );
	    break;

	case TAGForeachStatement:
	    res = is_GC_Cardinality_list( symtab, to_const_ForeachStatement(smt)->cards ) ||
		is_GC_Block( symtab, to_const_ForeachStatement(smt)->body );
	    break;

	case TAGClassicForStatement:
	    // I could have a better look, but they are rewritten
	    // almost immediately anyway.
	    res = true;
	    break;

    }
    return res;
}

// Forward declaration.
static bool is_GCsetting_expression_list( const_Entry_list symtab, const_expression_list xl );
static bool is_GCsetting_Block( const_Entry_list symtab, const_Block blk );
static bool is_GCsetting_statement_list( const_Entry_list symtab, const_statement_list xl );

// Given an expression 'x', return true if the expression may have garbage
// collection as side-effect.
static bool is_GCsetting_expression( const_Entry_list symtab, const_expression x )
{
    bool res = false;
    if( x == expressionNIL ){
	return false;
    }
    switch( x->tag ){
	case TAGBooleanExpression:
	case TAGByteExpression:
	case TAGCharExpression:
	case TAGClassIdExpression:
	case TAGClassInstanceOfExpression:
	case TAGDefaultValueExpression:
	case TAGDoubleExpression:
	case TAGFloatExpression:
	case TAGGetBufExpression:
	case TAGGetLengthExpression:
	case TAGGetSizeExpression:
	case TAGInstanceOfExpression:
	case TAGIntExpression:
	case TAGInterfaceInstanceOfExpression:
	case TAGLongExpression:
	case TAGNewArrayExpression:
	case TAGNewRecordExpression:
	case TAGNotNullAssertExpression:
	case TAGNullExpression:
	case TAGOuterSuperFieldExpression:
	case TAGOuterThisExpression:
	case TAGShortExpression:
	case TAGSizeofExpression:
	case TAGSuperFieldExpression:
	case TAGTypeExpression:
	case TAGTypeFieldExpression:
	case TAGTypeInstanceOfExpression:
	case TAGVariableNameExpression:
	    res = false;
	    break;

	// At the point we are looking at this, string init is already
	// explicit. String constants themselves don't cause GC.
	case TAGStringExpression:
	    res = false;
	    break;

	case TAGArrayInitExpression:
	case TAGClassExpression:
	case TAGFieldInvocationExpression:
	case TAGNewClassExpression:
	case TAGNewInitArrayExpression:
	case TAGNewInnerClassExpression:
	case TAGOuterSuperInvocationExpression:
	case TAGTypeInvocationExpression:
	case TAGSuperInvocationExpression:
	case TAGConstructorInvocationExpression:
	    res = true;
	    break;

	case TAGAssignOpExpression:
	    // TODO: have a better look
	    res = true;
	    break;

	case TAGMethodInvocationExpression:
	    res = true;
	    break;

	case TAGWhereExpression:
	    // TODO: have a better look
	    res = true;
	    break;

	case TAGVectorExpression:
	    res = is_GCsetting_expression_list( symtab, to_const_VectorExpression(x)->fields );
	    break;

	case TAGSubscriptExpression:
	    res = is_GCsetting_expression( symtab, to_const_SubscriptExpression(x)->array )
		|| is_GCsetting_expression( symtab, to_const_SubscriptExpression(x)->subscripts );
	    break;

	case TAGVectorSubscriptExpression:
	    res = is_GCsetting_expression( symtab, to_const_VectorSubscriptExpression(x)->vector );
	    break;

	case TAGFieldExpression:
	    res = is_GCsetting_expression( symtab, to_const_FieldExpression(x)->rec );
	    break;

	case TAGPreIncrementExpression:
	    res = is_GCsetting_expression( symtab, to_const_PreIncrementExpression(x)->x );
	    break;

	case TAGPreDecrementExpression:
	    res = is_GCsetting_expression( symtab, to_const_PreDecrementExpression(x)->x );
	    break;

	case TAGPostIncrementExpression:
	    res = is_GCsetting_expression( symtab, to_const_PostIncrementExpression(x)->x );
	    break;

	case TAGPostDecrementExpression:
	    res = is_GCsetting_expression( symtab, to_const_PostDecrementExpression(x)->x );
	    break;

	case TAGForcedCastExpression:
	    res = is_GCsetting_expression( symtab, to_const_ForcedCastExpression(x)->x );
	    break;

	case TAGCastExpression:
	    res = is_GCsetting_expression( symtab, to_const_CastExpression(x)->x );
	    break;

	case TAGAnnotationExpression:
	{
	    const_AnnotationExpression cx = to_const_AnnotationExpression( x );
	    res = is_GCsetting_expression( symtab, cx->x );
	    break;
	}

	case TAGComplexExpression:
	{
	    const_ComplexExpression cx = to_const_ComplexExpression( x );
	    res = is_GCsetting_expression( symtab, cx->re ) &&
		is_GCsetting_expression( symtab, cx->im );
	    break;
	}

	case TAGIfExpression:
	{
	    const_IfExpression cx = to_const_IfExpression( x );
	    res = is_GCsetting_expression( symtab, cx->cond ) &&
		is_GCsetting_expression( symtab, cx->thenval ) &&
		is_GCsetting_expression( symtab, cx->elseval );
	    break;
	}

	case TAGUnopExpression:
	{
	    const_UnopExpression cx = to_const_UnopExpression( x );
	    res = is_GCsetting_expression( symtab, cx->operand );
	    break;
	}

	case TAGBinopExpression:
	{
	    const_BinopExpression cx = to_const_BinopExpression( x );
	    res = is_GCsetting_expression( symtab, cx->left ) && is_GCsetting_expression( symtab, cx->right );
	    break;
	}

    }
    return res;
}

// Given an optional expression 'x', return true iff the expression may have
// garbage collection as side-effect.
static bool is_GCsetting_expression( const_Entry_list symtab, const_optexpression x )
{
    bool res = false;

    switch( x->tag ){
	case TAGOptExpr:
	    res =  is_GCsetting_expression( symtab, to_const_OptExpr(x)->x );
	    break;

	case TAGOptExprNone:
	    res = false;
	    break;
    }
    return res;
}

static bool is_GCsetting_expression_list( const_Entry_list symtab, const_expression_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GCsetting_expression( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GCsetting_Catch( const_Entry_list symtab, const_Catch c )
{
    return is_GCsetting_Block( symtab, c->body );
}

static bool is_GCsetting_Catch_list( const_Entry_list symtab, const_Catch_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GCsetting_Catch( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GCsetting_Cardinality( const_Entry_list symtab, const_Cardinality card )
{
    return is_GCsetting_expression( symtab, card->lowerbound ) ||
	is_GCsetting_expression( symtab, card->upperbound ) ||
	is_GCsetting_expression( symtab, card->stride );
}

static bool is_GCsetting_Cardinality_list( const_Entry_list symtab, const_Cardinality_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GCsetting_Cardinality( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GCsetting_SwitchCase( const_Entry_list symtab, const_SwitchCase c )
{
    if( is_GCsetting_statement_list( symtab, c->body ) ){
	return true;
    }
    bool res = false;

    switch( c->tag ){
	case TAGSwitchCaseValue:
	    res = is_GCsetting_expression( symtab, to_const_SwitchCaseValue(c)->cond );
	    break;

	case TAGSwitchCaseDefault:
	    break;
    }
    return res;
}

static bool is_GCsetting_SwitchCase_list( const_Entry_list symtab, const_SwitchCase_list xl )
{
    for( unsigned int ix=0; ix<xl->sz; ix++ ){
	if( is_GCsetting_SwitchCase( symtab, xl->arr[ix] ) ){
	    return true;
	}
    }
    return false;
}

static bool is_GCsetting_statement_list( const_Entry_list symtab, const_statement_list xl )
{
    if( xl != statement_listNIL ){
	for( unsigned int ix=0; ix<xl->sz; ix++ ){
	    if( is_GCsetting_statement( symtab, xl->arr[ix] ) ){
		return true;
	    }
	}
    }
    return false;
}

static bool is_GCsetting_Block( const_Entry_list symtab, const_Block blk )
{
    return is_GCsetting_statement_list( symtab, blk->statements );
}

// Given a statement, return true iff the statement may set __gc_reflink_chain
// Compound statements return true, since we cannot be bothered to have
// a look inside them.
//
// The main source of 'true' returns are invocations of functions and
// procedures.  More detailed analysis may reveal that a function/procedure
// does not, in fact, set __gc_reflink_chain, but such refinement is for later.
bool is_GCsetting_statement( const_Entry_list symtab, const_statement smt )
{
    bool res = false;

    switch( smt->tag ){
	case TAGClassDeclaration:
	case TAGInterfaceDeclaration:
	case TAGFunctionDeclaration:
	case TAGNativeFunctionDeclaration:
	case TAGAbstractFunctionDeclaration:
	case TAGGotoStatement:
	case TAGReturnStatement:
	case TAGConstructorDeclaration:
	case TAGEmptyStatement:
	case TAGBreakStatement:
	case TAGContinueStatement:
	case TAGGCBuildRefChainLinkStatement:
	case TAGGCSetRefChainLinkStatement:
	case TAGGCSetTopRefChainLinkStatement:
	case TAGInstanceInitializer:
	    res = false;
	    break;

	case TAGTryStatement:
	    res = is_GCsetting_Block( symtab, to_const_TryStatement(smt)->body ) ||
		is_GCsetting_Catch_list( symtab, to_const_TryStatement(smt)->catches ) ||
		is_GCsetting_Block( symtab, to_const_TryStatement(smt)->finally );
	    break;

	case TAGSimpleTryStatement:
	    res = is_GCsetting_Block( symtab, to_const_SimpleTryStatement(smt)->body ) ||
		is_GCsetting_Block( symtab, to_const_SimpleTryStatement(smt)->catches );
	    break;

	case TAGOuterSuperInvocationStatement:
	case TAGTypeInvocationStatement:
	case TAGFieldInvocationStatement:
	case TAGSuperConstructorInvocationStatement:
	case TAGSuperInvocationStatement:
	case TAGOuterSuperConstructorInvocationStatement:
	case TAGThisConstructorInvocationStatement:
	case TAGStaticInitializer:
	case TAGMethodInvocationStatement:
	    res = true;
	    break;

	case TAGEachStatement:
	    res = is_GCsetting_statement_list( symtab, to_const_EachStatement(smt)->statements );
	    break;

	case TAGValueReturnStatement:
	    res = is_GCsetting_expression( symtab, to_const_ValueReturnStatement(smt)->v );
	    break;

	case TAGInternalThrowStatement:
	    res = is_GCsetting_expression( symtab, to_const_InternalThrowStatement(smt)->x );
	    break;

	case TAGSynchronizedStatement:
	    res = is_GCsetting_expression( symtab, to_const_SynchronizedStatement(smt)->on ) ||
		is_GCsetting_Block( symtab, to_const_SynchronizedStatement(smt)->body );
	    break;

	case TAGThrowStatement:
	    res = is_GCsetting_expression( symtab, to_const_ThrowStatement(smt)->x );
	    break;

	case TAGIfStatement:
	    res =
		is_GCsetting_expression( symtab, to_const_IfStatement(smt)->cond ) ||
		is_GCsetting_Block( symtab, to_const_IfStatement(smt)->thenbody ) ||
		is_GCsetting_Block( symtab, to_const_IfStatement(smt)->elsebody );
	    break;

	case TAGBlockStatement:
	    res = is_GCsetting_Block( symtab, to_const_BlockStatement(smt)->body );
	    break;

	case TAGDoWhileStatement:
	    res = is_GCsetting_expression( symtab, to_const_DoWhileStatement(smt)->cond ) ||
		is_GCsetting_Block( symtab, to_const_DoWhileStatement(smt)->body ) ||
		is_GCsetting_statement_list( symtab, to_const_DoWhileStatement(smt)->update );
	    break;

	case TAGWhileStatement:
	    res = is_GCsetting_expression( symtab, to_const_WhileStatement(smt)->cond ) ||
		is_GCsetting_Block( symtab, to_const_WhileStatement(smt)->body ) ||
		is_GCsetting_statement_list( symtab, to_const_WhileStatement(smt)->update );
	    break;

	case TAGSwitchStatement:
	    res = is_GCsetting_expression( symtab, to_const_SwitchStatement(smt)->cond ) ||
		is_GCsetting_SwitchCase_list( symtab, to_const_SwitchStatement(smt)->cases );
	    break;

	case TAGExpressionStatement:
	    res = is_GCsetting_expression( symtab, to_const_ExpressionStatement(smt)->x );
	    break;

	case TAGDeleteStatement:
	    res = is_GCsetting_expression( symtab, to_const_DeleteStatement(smt)->adr );
	    break;

	case TAGAssignStatement:
	    res = is_GCsetting_expression( symtab, to_const_AssignStatement(smt)->lhs )
	     || is_GCsetting_expression( symtab, to_const_AssignStatement(smt)->rhs );
	    break;

	case TAGFieldDeclaration:
	    res = is_GCsetting_expression( symtab, to_const_FieldDeclaration(smt)->init );
	    break;

	case TAGPrintStatement:
	    res = is_GCsetting_expression_list( symtab, to_const_PrintStatement(smt)->argv );
	    break;

	case TAGPrintLineStatement:
	    res = is_GCsetting_expression_list( symtab, to_const_PrintLineStatement(smt)->argv );
	    break;

	case TAGForStatement:
	    res = is_GCsetting_Cardinality_list( symtab, to_const_ForStatement(smt)->cards ) ||
		is_GCsetting_Block( symtab, to_const_ForStatement(smt)->body );
	    break;

	case TAGForeachStatement:
	    res = is_GCsetting_Cardinality_list( symtab, to_const_ForeachStatement(smt)->cards ) ||
		is_GCsetting_Block( symtab, to_const_ForeachStatement(smt)->body );
	    break;

	case TAGClassicForStatement:
	    // I could have a better look, but they are rewritten
	    // almost immediately anyway.
	    res = true;
	    break;

    }
    return res;
}

static AFLAG is_zerotrip_Cardinality( const_Cardinality card )
{
    vnus_int lower;
    vnus_int upper;

    if( card->lowerbound == expressionNIL ){
	lower = 0;
    }
    else if( card->lowerbound->tag == TAGIntExpression ){
	lower = to_const_IntExpression( card->lowerbound )->v;
    }
    else {
	return AF_MAYBE;
    }
    if( card->upperbound->tag == TAGIntExpression ){
	upper = to_const_IntExpression( card->upperbound )->v;
    }
    else {
	return AF_MAYBE;
    }
    if( lower == upper ){
	return AF_YES;
    }
    return AF_NO;
}

AFLAG is_zerotrip_Cardinality_list( const_Cardinality_list cards )
{
    AFLAG res = AF_NO;

    for( unsigned int ix=0; ix<cards->sz; ix++ ){
	AFLAG r1 = is_zerotrip_Cardinality( cards->arr[ix] );

	if( r1 == AF_YES ){
	    return AF_YES;
	}
	if( r1 == AF_MAYBE ){
	    res = AF_MAYBE;
	}
    }
    return res;
}

