/* File: global.c
 *
 * Global variables.
 * Obviously, there should be as few global variables as possible.
 * Main candidates are debugging and tracing switches.
 */

#include <stdlib.h>
#include <stdio.h>
#include <tmc.h>

#include "defs.h"
#include "tmadmin.h"
#include "global.h"

/* debugging flags */
int array_class = FALSE;
int dumpmangledtree = FALSE;
int dumptree = FALSE;
int givestat = FALSE;
int lextr = FALSE;
int no_boundscheck = FALSE;
int no_inlining = FALSE;
int showmangling = FALSE;
int showmethodbinding = FALSE;
int trace_analysis = FALSE;
int trace_bindings = FALSE;
int trace_files = FALSE;
int trace_generics = FALSE;
int trace_imports = FALSE;
int trace_inlining = FALSE;
int trace_innerclasses = FALSE;
int trace_symtab = FALSE;
int trace_typelist = FALSE;
int trace_usage = FALSE;
int trace_vtable = FALSE;

int warn_ignoredvalue = FALSE;
int warn_semicolon = FALSE;
unsigned int features = 0xffff & ~FEAT_INPRAGMA;
unsigned int spar_features = 0xffff & ~FEAT_INPRAGMA;
unsigned int java_features = 0xffff & ~FEAT_INPRAGMA;

int pref_nonotnullassert = 0;
int pref_nogarbagecollection = 0;
int pref_strictanalysis = 0;

tmstring_list sparpath = 0;
