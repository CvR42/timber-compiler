/* File: fwdregtype.h */

extern void fwdregtype_SparProgramUnit( SparProgram *prog, SparProgramUnit unit );
