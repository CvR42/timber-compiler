/* File: collect.c
 *
 * Routines that collect names from various parts of the vnus parse tree.
 */

#include <stdio.h>
#include <tmc.h>
#include <assert.h>

#include "defs.h"
#include "config.h"
#include "tmadmin.h"
#include "error.h"
#include "symbol_table.h"
#include "global.h"
#include "collect.h"
#include "typederive.h"
#include "service.h"

/* Given an FormalParameter list, return the list of FormalParameter names occuring
 * in that list.
 */
origsymbol_list collect_FormalParameter_names( origsymbol_list ans, const_FormalParameter_list l )
{

    ans = setroom_origsymbol_list( ans, ans->sz+l->sz );
    for( unsigned int ix=0; ix<l->sz; ix++ ){
	origsymbol s = rdup_origsymbol( l->arr[ix]->name );
	ans = append_origsymbol_list( ans, s );
	assert( s->sym != tmsymbolNIL );
    }
    return ans;
}

// Given a list of declarations, collect the symbols symbols of declared
// variables.
origsymbol_list collect_vardeclaration_names( origsymbol_list nms, const_statement_list l )
{
    if( l == statement_listNIL ){
	return nms;
    }
    for( unsigned int ix=0; ix<l->sz; ix++ ){
	statement smt = l->arr[ix];

	if( is_VariableDeclaration( smt ) ){
	    nms = append_origsymbol_list(
		nms,
		rdup_origsymbol( to_VariableDeclaration( smt )->name )
	    );
	}
    }
    return nms;
}

/* Given a Cardinality list, return the symbols that are used in it. */
origsymbol_list collect_Cardinality_symbols( const_Cardinality_list l )
{
    origsymbol_list ans = new_origsymbol_list();

    ans = setroom_origsymbol_list( ans, l->sz );
    for( unsigned int ix=0; ix<l->sz; ix++ ){
	origsymbol s = rdup_origsymbol( l->arr[ix]->name );
	ans = append_origsymbol_list( ans, s );
	assert( s->sym != tmsymbolNIL );
    }
    return ans;
}

/* Given a Vnus program, return a list of all global symbols. */
void collect_global_symbols(
 origsymbol_list *global_variables,
 Signature_list *global_methods,
 origsymbol_list *classes,
 origsymbol_list *external_variables,
 Signature_list *external_methods,
 SparProgramUnit unit
)
{
    statement_list l = unit->decls;

    *global_variables = new_origsymbol_list();
    *global_methods = new_Signature_list();
    *external_methods = new_Signature_list();
    *external_variables = new_origsymbol_list();
    *classes = new_origsymbol_list();
    for( unsigned int ix=0; ix<l->sz; ix++ ){
	statement d = l->arr[ix];

	switch( d->tag ){
	    case TAGFunctionDeclaration:
		*global_methods = append_Signature_list(
		    *global_methods,
		    new_Signature(
			to_declaration(d)->flags,
			rdup_tmsymbol( to_MethodDeclaration(d)->name->sym ),
			derive_type_FormalParameter_list( to_MethodDeclaration(d)->parameters )
		    )
		);
		break;

	    case TAGFieldDeclaration:
		*global_variables = append_origsymbol_list(
		    *global_variables,
		    rdup_origsymbol( to_VariableDeclaration(d)->name )
		);
		break;

	    case TAGClassDeclaration:
	    case TAGInterfaceDeclaration:
		*classes = append_origsymbol_list(
		    *classes,
		    rdup_origsymbol( to_TypeDeclaration(d)->name )
		);
		break;

	    case TAGNativeFunctionDeclaration:
		*external_methods = append_Signature_list(
		    *external_methods,
		    new_Signature(
			to_declaration(d)->flags,
			rdup_tmsymbol( to_MethodDeclaration(d)->name->sym ),
			derive_type_FormalParameter_list( to_MethodDeclaration(d)->parameters )
		    )
		);
		break;

	    case TAGAbstractFunctionDeclaration:
	    case TAGGCBuildRefChainLinkStatement:
	    case TAGGCSetRefChainLinkStatement:
	    case TAGGCSetTopRefChainLinkStatement:
	    case TAGAssignStatement:
	    case TAGBlockStatement:
	    case TAGBreakStatement:
	    case TAGClassicForStatement:
	    case TAGConstructorDeclaration:
	    case TAGContinueStatement:
	    case TAGDeleteStatement:
	    case TAGDoWhileStatement:
	    case TAGEachStatement:
	    case TAGEmptyStatement:
	    case TAGExpressionStatement:
	    case TAGFieldInvocationStatement:
	    case TAGForStatement:
	    case TAGForeachStatement:
	    case TAGGotoStatement:
	    case TAGIfStatement:
	    case TAGMethodInvocationStatement:
	    case TAGPrintLineStatement:
	    case TAGPrintStatement:
	    case TAGReturnStatement:
	    case TAGSimpleTryStatement:
	    case TAGStaticInitializer:
	    case TAGInstanceInitializer:
	    case TAGSuperConstructorInvocationStatement:
	    case TAGOuterSuperInvocationStatement:
	    case TAGSuperInvocationStatement:
	    case TAGOuterSuperConstructorInvocationStatement:
	    case TAGSwitchStatement:
	    case TAGSynchronizedStatement:
	    case TAGThisConstructorInvocationStatement:
	    case TAGThrowStatement:
	    case TAGInternalThrowStatement:
	    case TAGTryStatement:
	    case TAGTypeInvocationStatement:
	    case TAGValueReturnStatement:
	    case TAGWhileStatement:
		break;

	}
    }
}

/* Given a function definition, return all the local symbols in
 * that definition. We assume the declarations are correct.
 */
origsymbol_list collect_function_names(
 const_FormalParameter_list args,
 const_statement_list ldecl
)
{
    origsymbol_list locals;

    locals = new_origsymbol_list();
    if( args != FormalParameter_listNIL ){
	locals = collect_FormalParameter_names( locals, args );
    }
    if( ldecl != statement_listNIL ){
	locals = collect_vardeclaration_names( locals, ldecl );
    }
    return locals;
}

/* Given a list of labeled statements, return a list of labels
 * of these statements.
 */
origsymbol_list collect_labels( const_statement_list l )
{
    origsymbol_list ans = new_origsymbol_list();

    for( unsigned int ix=0; ix<l->sz; ix++ ){
	const_statement s = l->arr[ix];
	origsymbol_list labels = s->labels;
	if( labels != origsymbol_listNIL ){
	    ans = concat_origsymbol_list(
		ans,
		rdup_origsymbol_list( labels )
	    );
	}
    }
    return ans;
}

/* Collect class or interface fields, in the order they appear. */
Field_list collect_type_fields( const_statement_list sl, bool force_static )
{
    Field_list res;
    unsigned int ix;
    modflags mask = 0;

    if( force_static ){
	mask = ACC_STATIC;
    }
    res = setroom_Field_list( new_Field_list(), sl->sz );
    for( ix=0; ix<sl->sz; ix++ ){
	statement s = sl->arr[ix];

	if( is_VariableDeclaration( s ) ){
	    res = append_Field_list(
		res,
		new_Field(
		    mask | to_declaration(s)->flags,
		    to_VariableDeclaration( s )->name->sym
		)
	    );
	}
    }
    return res;
}

/* Collect class methods, in the order they appear. If force_static
 * is true, set the ACC_STATIC flag in all collected signatures.
 */
Signature_list collect_type_methods( const_statement_list sl, bool force_static )
{
    modflags mask = 0;

    if( force_static ){
	mask = ACC_STATIC;
    }
    Signature_list res = setroom_Signature_list( new_Signature_list(), sl->sz );
    for( unsigned int ix=0; ix<sl->sz; ix++ ){
	const_statement smt = sl->arr[ix];

	if( is_MethodDeclaration( smt ) && smt->tag != TAGConstructorDeclaration ){
	    type_list formals = derive_type_FormalParameter_list(
		to_const_MethodDeclaration( smt )->parameters
	    );
	    modflags flags = mask | to_const_declaration(smt)->flags;

	    Signature s = new_Signature(
		flags,
		rdup_tmsymbol( to_const_MethodDeclaration( smt )->name->sym ),
		formals
	    );
	    res = append_Signature_list( res, s );
	}
    }
    return res;
}

/* Collect class constructors. */
Signature_list collect_class_constructors( const_statement_list sl )
{
    Signature_list res = new_Signature_list();
    for( unsigned ix=0; ix<sl->sz; ix++ ){
	const_statement s = sl->arr[ix];

	if( s->tag == TAGConstructorDeclaration ){
	    res = append_Signature_list(
		res,
		new_Signature(
		    to_const_declaration(s)->flags,
		    to_const_MethodDeclaration( s )->name->sym,
		    derive_type_FormalParameter_list(
			to_const_MethodDeclaration( s )->parameters
		    )
		)
	    );
	}
    }
    return res;
}

/* Collect class constructors. */
origsymbol_list collect_unit_types( const_statement_list sl )
{
    origsymbol_list res = new_origsymbol_list();
    for( unsigned int ix=0; ix<sl->sz; ix++ ){
	const_statement s = sl->arr[ix];

	if( is_TypeDeclaration( s ) ){
	    res = append_origsymbol_list(
		res,
		rdup_origsymbol( to_const_TypeDeclaration(s)->name )
	    );
	}
    }
    return res;
}

MethodMapping_list collect_global_methodmappings( const_Entry_list symtab )
{
    MethodMapping_list mappings = new_MethodMapping_list();

    for( unsigned int ix=0; ix<symtab->sz; ix++ ){
	const_Entry e = symtab->arr[ix];

	if( is_MethodEntry( e ) ){
	    mappings = append_MethodMapping_list(
		mappings,
		new_MethodMapping(
		    rdup_Signature( to_const_MethodEntry( e )->realname ),
		    rdup_tmsymbol( e->name ),
		    e->owner
		)
	    );
	}
    }
    return mappings;
}

// Given a list of types and a type name, return all the
// interfaces of this class in depth-first order. That is, a super-interface
// is listed before the class or interface that refer to it.
static inline tmsymbol_list collect_interfaces(
 const_TypeEntry_list types,
 tmsymbol_list all,
 tmsymbol nm
){
    if( nm == tmsymbolNIL ){
	return all;
    }
    TypeEntry e = lookup_TypeEntry( types, nm );
    return collect_interfaces( types, all, e );
}

// Given a list of types and a type name, return all the
// interfaces of this class in depth-first order. That is, a super-interface
// is listed before the class or interface that refer to it.
static inline tmsymbol_list collect_interfaces(
 const_TypeEntry_list types,
 tmsymbol_list all,
 const_origsymbol nm
){
    if( nm == origsymbolNIL ){
	return all;
    }
    return collect_interfaces( types, all, nm->sym );
}

// Given a list of types and a type name, return all the
// interfaces of this class in depth-first order. That is, a super-interface
// is listed before the class or interface that refer to it.
static inline tmsymbol_list collect_interfaces(
 const_TypeEntry_list types,
 tmsymbol_list all,
 const_type t
)
{
    if( t == typeNIL ){
	return all;
    }
    assert( t->tag == TAGObjectType );
    return collect_interfaces( types, all, to_const_ObjectType(t)->name );
}

// Given a list of types and an entry in this list, return all the
// interfaces of this class in depth-first order. That is, a super-interface
// is listed before the class or interface that refer to it.
tmsymbol_list collect_interfaces(
 const_TypeEntry_list types,
 tmsymbol_list all,
 const_TypeEntry e
)
{
    switch( e->tag ){
	case TAGClassEntry:
	{
	    const_type_list l = to_const_ClassEntry( e )->interfaces;

	    const_type tsuper = to_const_ClassEntry( e )->super;
	    all = collect_interfaces( types, all, tsuper );
	    for( unsigned int ix=0; ix<l->sz; ix++ ){
		const_type t = l->arr[ix];
		if( t != typeNIL && t->tag == TAGObjectType ){
		    tmsymbol s = to_const_ObjectType(t)->name->sym;
		    if( !member_tmsymbol_list( all, s ) ){
			all = collect_interfaces( types, all, s );
			all = append_tmsymbol_list( all, rdup_tmsymbol( s ) );
		    }
		}
	    }
	    break;
	}

	case TAGInterfaceEntry:
	{
	    const_type_list l = to_const_InterfaceEntry( e )->interfaces;

	    for( unsigned int ix=0; ix<l->sz; ix++ ){
		const_type t = l->arr[ix];
		if( t->tag == TAGObjectType ){
		    tmsymbol s = to_const_ObjectType(t)->name->sym;
		    if( !member_tmsymbol_list( all, s ) ){
			all = collect_interfaces( types, all, s );
			all = append_tmsymbol_list( all, rdup_tmsymbol( s ) );
		    }
		}
	    }
	    break;
	}

	case TAGPackageEntry:
	case TAGForwardObjectEntry:
	    break;
    }
    return all;
}

// Given a list of types, make sure that all of these types are ObjectType-s,
// and return a new list with all the names of these types.
origsymbol_list collect_names_type_list( const_type_list tl )
{
    origsymbol_list res = setroom_origsymbol_list( new_origsymbol_list(), tl->sz );
    for( unsigned int ix=0; ix<tl->sz; ix++ ){
	type t = tl->arr[ix];

	assert( t->tag == TAGObjectType );
	res = append_origsymbol_list(
	    res, 
	    rdup_origsymbol( to_ObjectType(t)->name )
	);
    }
    return res;
}
