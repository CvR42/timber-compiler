// File: getfilestring.h

extern char *get_file_string( VnusChar *nm, VnusInt len );
