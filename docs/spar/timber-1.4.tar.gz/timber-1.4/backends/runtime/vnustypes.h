#ifndef __VNUSTYPES_H__
#define __VNUSTYPES_H__

// CvR: quick fix; the endian.h in /usr/local/pthreads/include gets
// upset about the most recent egcs version, since in that one
// the preprocessor variable 'i386' is no longer defined if the
// -ansi flag is given.
#if defined( __i386__ ) && !defined( i386 )
#define i386 __i386__
#endif
#include <complex.h>
#include <longlong.h>
typedef signed char VnusByte;
typedef short VnusShort;
typedef int VnusInt;
#ifdef __GNUC__
__extension__ typedef long long int VnusLong;
#else
typedef signed_longlong VnusLong;
#endif
typedef float VnusFloat;
typedef double VnusDouble;
typedef complex<double> VnusComplex;
typedef bool VnusBoolean;
typedef char VnusChar;
typedef const char * VnusString;

/* The following types are only necessary to implement >>> */
typedef unsigned char UnsignedVnusByte;
typedef unsigned short UnsignedVnusShort;
typedef unsigned int UnsignedVnusInt;
#ifdef __GNUC__
__extension__ typedef unsigned long long UnsignedVnusLong;
#else
typedef unsigned_longlong UnsignedVnusLong;
#endif

#endif
