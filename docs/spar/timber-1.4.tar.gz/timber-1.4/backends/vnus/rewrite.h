/* File: rewrite.h */

extern vnusprog rewrite_vnusprog( vnusprog elm );
