// File: isgcsetting.h

extern bool is_GCsetting_statement( const_Entry_list symtab, const_statement smt );
