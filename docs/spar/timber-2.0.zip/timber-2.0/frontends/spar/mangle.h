/* File: mangle.h */

extern SparProgram mangle_SparProgram( SparProgram prog, const_SparProgramUnit unit, bool verifymode );
