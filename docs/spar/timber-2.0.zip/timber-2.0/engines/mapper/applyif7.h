/* File: applyif7.h */

extern vnusprog apply_if7( vnusprog elm, global_context gc );
