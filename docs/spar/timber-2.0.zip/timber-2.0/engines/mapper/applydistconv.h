/* File: applydistconv.h */

extern vnusprog apply_dist_conv( vnusprog elm, global_context gc );
