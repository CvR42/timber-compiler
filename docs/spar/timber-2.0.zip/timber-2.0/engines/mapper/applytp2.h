/* File: applytp2.h */

extern vnusprog apply_tp2( vnusprog elm, global_context gc );
