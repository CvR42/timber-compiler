/* File: applyit02.h */

extern vnusprog apply_it02( vnusprog elm, global_context gc );
