/* File: hoist_on.h */

extern vnusprog apply_hoist_on( vnusprog elm);
