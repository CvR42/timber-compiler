/* File: check.h
 *
 * Header file for check.c
 */

extern void check_vnusprog( const vnusprog p );
