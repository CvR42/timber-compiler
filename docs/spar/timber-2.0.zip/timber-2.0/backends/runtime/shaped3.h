// File: shaped3.h

#ifndef __SHAPED3_H__
#define __SHAPED3_H__

#include "polywrite.h"
#include "vnusstd.h"
#include "shapebase.h"
#include "arrayboundviolated.h"
#include <stdio.h>
#include <string.h>

template<class T> class ShapeD3 : public ShapeBase<T>
{
  private:
    const VnusInt dim0;
    const VnusInt dim1;
    const VnusInt dim2;

  public:
    ShapeD3( VnusBase::markfntype markfn, const VnusInt card0, const VnusInt card1, const VnusInt card2 ):
     ShapeBase<T>( markfn, card0*card1*card2 ), dim0(card0), dim1(card1), dim2(card2)
    {
	this->values = (T *) vnus_alloc_array( sizeof( T ), this->size, true );
    }
    
        // Constructor for intialized arrays.
    ShapeD3( VnusBase::markfntype markfn, T *arr, const VnusInt asz, const VnusInt card0, const VnusInt card1, const VnusInt card2 ):
     ShapeBase<T>( markfn, card0*card1*card2 ), dim0(card0), dim1(card1), dim2(card2)
    {
        if( asz != this->size ){
            fprintf(stderr,"*** ERROR -- \n");
            fprintf(stderr,"    Initializer array has %d  elms, but %d elms are required\n",asz,this->size);
            exit(1);
        }
	this->values = (T *) vnus_alloc_array( sizeof( T ), this->size, false );
	memcpy( this->values, arr, sizeof( T )*asz );
    }

    inline ShapeD3( const ShapeD3<T>& theShape):
     ShapeBase<T>(theShape),dim0(theShape.dim0),dim1(theShape.dim1),dim2(theShape.dim2)
    {
    }
    
    virtual inline ~ShapeD3()
    {
    }

    // Assign one shape to another, but only if they are exactly alike.
    ShapeD3<T>& operator= (const ShapeD3<T>& theShape)
    {
        if( this == &theShape ){
            return *this;
        }
	if( dim0 != theShape.GetSize(0) ){
	    fprintf(stderr, "*** ERROR -- \n");
	    fprintf(stderr, "    Sizes don't match in dimension 0 (%d != %d)\n",dim0,theShape.GetSize(0));
	    exit(1);
	}
	if( dim1 != theShape.GetSize(1) ){
	    fprintf(stderr, "*** ERROR -- \n");
	    fprintf(stderr, "    Sizes don't match in dimension 1 (%d != %d)\n",dim1,theShape.GetSize(1));
	    exit(1);
	}
	if( dim2 != theShape.GetSize(2) ){
	    fprintf(stderr, "*** ERROR -- \n");
	    fprintf(stderr, "    Sizes don't match in dimension 2 (%d != %d)\n",dim2,theShape.GetSize(2));
	    exit(1);
	}
        ShapeBase<T>::operator=(theShape);
        return *this;
    }

    inline T& operator() ( const VnusInt i0, const VnusInt i1, const VnusInt i2 ) const
    {
        return AccessChecked( i0, i1, i2 );
    }

    inline T& AccessChecked( const VnusInt i0, const VnusInt i1, const VnusInt i2 ) const
    {
        CheckIndex( i0, i1, i2 );
        return AccessNotChecked( i0, i1, i2 );
    }

    // Access to a shape element.
    // Similar to above, but these functions are not virtual.
    // Access to these functions is generated if it is known whether
    // the array is a shape.
    inline T& AccessNotChecked( const VnusInt i0, const VnusInt i1, const VnusInt i2 ) const
    {
        return this->values[(i0*dim1+i1)*dim2+i2];
    }

    inline void CheckIndex( const VnusInt i0, const VnusInt i1, const VnusInt i2 ) const
    {
	if(
	    (((UnsignedVnusInt) i0)>= (UnsignedVnusInt) dim0) ||
	    (((UnsignedVnusInt) i1)>= (UnsignedVnusInt) dim1) ||
	    (((UnsignedVnusInt) i2)>= (UnsignedVnusInt) dim2)
	){
	    VnusEventArrayBoundViolated();
	}
    }

    inline VnusInt GetSize( const VnusInt dim ) const
    {
	switch( dim ){
	    case 0:
		return dim0;

	    case 1:
		return dim1;

	    case 2:
		return dim2;

	    default:
                runtime_error("ShapeD3::GetSize: Illegal dimension");
	}
        return -1;
    }

    void PrintInfo( FILE* out )
    {
        fprintf(out,"Shape[rank:3,size:%d]",this->size);
    }
    

    inline ShapeD3<T>* Fill (const T defaultValue)
    {
        return (ShapeD3<T>*)ShapeBase<T>::Fill(defaultValue);
    }

};

#endif
