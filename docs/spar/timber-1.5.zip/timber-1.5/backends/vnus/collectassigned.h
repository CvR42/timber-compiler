// File: collectassigned.h

extern void collectassigned_block( const_block decl, tmsymbol_list *vars, bool *inv );
