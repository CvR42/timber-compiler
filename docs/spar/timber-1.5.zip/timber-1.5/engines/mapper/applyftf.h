/* File: applyftf.h */

extern vnusprog apply_ftf( vnusprog elm, global_context gc );
