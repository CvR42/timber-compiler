/* File: applyclean3.h */

extern vnusprog apply_clean3( vnusprog elm, global_context gc );
