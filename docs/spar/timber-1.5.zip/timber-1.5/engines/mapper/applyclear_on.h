/* File: applyclear_on.h */

extern vnusprog apply_clear_on( vnusprog elm, global_context gc );
