/* File: applyca3.h */

extern vnusprog apply_ca3( vnusprog elm, global_context gc );
