/* File: applyif1.h */

extern vnusprog apply_if1( vnusprog elm, global_context gc );
