/* File: apply2owned.h */

extern vnusprog apply_2owned( vnusprog elm, global_context gc );
