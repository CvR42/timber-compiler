/* File: applyselect_on.h */

extern vnusprog apply_select_on( vnusprog elm, global_context gc );
