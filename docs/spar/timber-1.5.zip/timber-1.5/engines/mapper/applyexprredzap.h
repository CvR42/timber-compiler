/* File: applyexprredzap.h */

extern vnusprog apply_expr_red_zap( vnusprog elm, global_context gc );
