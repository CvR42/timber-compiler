/* File: select_on.h */

extern vnusprog apply_select_on( vnusprog elm);
