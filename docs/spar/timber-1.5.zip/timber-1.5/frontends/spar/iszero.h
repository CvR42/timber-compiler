// File: iszero.h

extern AFLAG is_zero( const_expression x, const_ProgramState_list state );
