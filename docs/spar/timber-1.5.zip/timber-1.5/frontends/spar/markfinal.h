// File: markfinal.h

extern MethodDeclaration markfinal_MethodDeclaration( MethodDeclaration decl );
