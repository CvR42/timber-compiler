// File: isconstant.h

extern bool is_constant( const_expression x );
