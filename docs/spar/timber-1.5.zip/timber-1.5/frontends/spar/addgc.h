// File: addgc.h

extern void addgc_SparProgram( SparProgram prog );
