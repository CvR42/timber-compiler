/* File: applycheck.h */

extern vnusprog apply_check( vnusprog elm, global_context gc );
