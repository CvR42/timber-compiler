/* File: applyif5.h */

extern vnusprog apply_if5( vnusprog elm, global_context gc );
