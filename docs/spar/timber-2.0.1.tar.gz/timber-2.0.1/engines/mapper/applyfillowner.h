/* File: applyfillowner.h */

extern vnusprog apply_fillowner( vnusprog elm, global_context gc );
