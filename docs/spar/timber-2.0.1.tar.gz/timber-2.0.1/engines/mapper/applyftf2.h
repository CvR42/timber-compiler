/* File: applyftf2.h */

extern vnusprog apply_ftf2( vnusprog elm, global_context gc );
