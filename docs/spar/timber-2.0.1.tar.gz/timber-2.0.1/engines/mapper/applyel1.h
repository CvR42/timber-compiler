/* File: applyel1.h */

extern vnusprog apply_el1( vnusprog elm, global_context gc );
