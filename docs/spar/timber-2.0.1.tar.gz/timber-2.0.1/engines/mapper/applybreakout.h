/* File: applybreakout.h */

extern vnusprog apply_breakout( vnusprog elm, global_context gc );
