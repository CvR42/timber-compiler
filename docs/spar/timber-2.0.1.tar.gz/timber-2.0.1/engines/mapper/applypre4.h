/* File: applypre4.h */

extern vnusprog apply_pre4( vnusprog elm, global_context gc );
