/* File: applydistcheck.h */

extern vnusprog apply_dist_check( vnusprog elm, global_context gc );
