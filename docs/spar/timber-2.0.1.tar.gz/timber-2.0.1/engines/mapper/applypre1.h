/* File: applypre1.h */

extern vnusprog apply_pre1( vnusprog elm, global_context gc );
