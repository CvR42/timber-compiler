/* File: applyca1.h */

extern vnusprog apply_ca1( vnusprog elm, global_context gc );
