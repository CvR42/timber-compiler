extern int issubset_owner_list(OwnerExpr_list oe_l1, OwnerExpr_list oe_l2);
extern int issubset_owner(OwnerExpr oe1, OwnerExpr oe2);
