// File: shape.h

#ifndef __SHAPE_H__
#define __SHAPE_H__

#include "shaped0.h"
#include "shaped1.h"
#include "shaped2.h"
#include "shaped3.h"
#include "shapedn.h"

#endif
