// File: codesize.h

extern int code_size_statement_list( const_statement_list sl, int limit );
