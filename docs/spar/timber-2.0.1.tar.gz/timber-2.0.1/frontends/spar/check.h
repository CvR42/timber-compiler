/* File: check.h
 *
 * Header file for check.c
 */

extern void check_SparProgram( SparProgram p );
