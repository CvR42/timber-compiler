// File: FillInStackTrace.cc

#include <vnustypes.h>
#include <vnusstd.h>
#include "spar-rtl.h"

void *Java_java_lang_Throwable_fillInStackTrace( void *ths )
{
    return ths;
}
