// File: getclassstring.h

extern char *get_class_string( const VnusChar *nm, VnusInt len );
