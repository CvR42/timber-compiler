#ifndef __MPIHACK_H__
#define __MPIHACK_H__

void Hack_Bsend(const void *buf, int sz);

void Hack_Recv(void *buf, int *sz);

#endif

