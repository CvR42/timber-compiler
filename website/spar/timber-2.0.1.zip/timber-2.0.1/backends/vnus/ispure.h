extern bool is_pure_expression( const_expression x );
extern bool is_pure_location( const_location x );
