extern bool is_pure( const_expression x );
