char spar_version[] = "development; do not distribute";
