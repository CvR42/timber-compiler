// File: getunbounds.h

extern void getunbounds_declaration( const_declaration d, origsymbol_list vars, const_tmsymbol_list superfields );
