// File: markadmin.h

extern const_arraymarker_list get_arraymarkers();
extern tmsymbol get_arraymarker_name( const_type t );
extern void clear_arraymarkers();
