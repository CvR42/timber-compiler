/* File: applyit2.h */

extern vnusprog apply_it2( vnusprog elm, global_context gc );
