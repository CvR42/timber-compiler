/* File: applyit1.h */

extern vnusprog apply_it1( vnusprog elm, global_context gc );
