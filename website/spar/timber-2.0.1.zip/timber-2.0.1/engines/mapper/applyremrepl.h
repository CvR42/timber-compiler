/* File: applyremrepl.h */

extern vnusprog apply_rem_repl( vnusprog elm, global_context gc );
