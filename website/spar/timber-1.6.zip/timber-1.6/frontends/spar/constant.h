/* File: constant.h */

extern vnus_long evaluate_integral_constant( const_expression x );
