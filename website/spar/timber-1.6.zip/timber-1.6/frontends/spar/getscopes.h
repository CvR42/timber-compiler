// File: getscopes.h

extern void getscopes_Block( const_Block blk, tmsymbol_list scopes, tmsymbol_list labels );
