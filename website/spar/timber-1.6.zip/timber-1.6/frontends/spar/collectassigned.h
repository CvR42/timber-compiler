// File: collectassigned.h

extern void collectassigned_Block( const_Block decl, tmsymbol_list *vars, bool *inv );
