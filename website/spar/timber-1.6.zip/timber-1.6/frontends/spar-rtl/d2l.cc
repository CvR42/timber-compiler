// File: d2l.cc
//

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <vnustypes.h>
#include <vnusstd.h>
#include "spar-rtl.h"

#ifdef __GNUC__
union hack {
    VnusDouble d;
    VnusLong l;
};
#endif

VnusLong Java_java_lang_Double_doubleToLongBits( VnusDouble v )
{
#ifdef __GNUC__
    hack x;

    x.d = v;
    return x.l;
#else
    return 0;
#endif
}
