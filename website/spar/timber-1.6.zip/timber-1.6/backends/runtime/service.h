/* File: service.h
 *
 * Header file for service.c
 */

#ifndef __SERVICE_H__
#define __SERVICE_H__

#include "vnustypes.h"

extern void euclid(
    const VnusInt alpha, const VnusInt beta,
    VnusInt *x0, VnusInt *y0,
    VnusInt *g,
    VnusInt *dx, VnusInt *dy
    );
//extern VnusInt floordiv( const VnusInt a, const VnusInt b );
//extern VnusInt ceildiv( const VnusInt a, const VnusInt b );
//extern void iterations(
//    const VnusInt l, const VnusInt u, const VnusInt s,
//    VnusInt *n, VnusInt *shift
//    );


/* NOTE NOTE NOTE NOTE NOTE
 * The code below is system-dependent. For the moment we assume
 * division rounds towards zero, but this may be different for other
 * machines.
 * NOTE NOTE NOTE NOTE NOTE
 */

/* Division with rounding down. */
inline VnusInt floordiv( VnusInt a, VnusInt b )
{
    if( b<0 ){
	a = -a;
	b = -b;
    }
    if( a>0 ){
	return a/b;
    }
    return (a-(b-1))/b;
}

/* Division with rounding up. */
inline VnusInt ceildiv( VnusInt a, VnusInt b )
{
    if( b<0 ){
	a = -a;
	b = -b;
    }
    if( a>0 ){
	return (a+(b-1))/b;
    }
    return a/b;
}

/* Range calculation. Given a lower bound 'l', upper bound 'u' and stride 's',
 * we assume an 'i' such that l <= i*s < u, (i in Z).
 * We calculate the lowest valid value of 'i', and assign it to
 * '*shift'. We also calculate the the number of valid values for 'i',
 * and assign it to '*n'.
 */
inline void iterations(
    const VnusInt l, const VnusInt u, const VnusInt s,
    VnusInt *n, VnusInt *shift
)
{
    *shift = ceildiv( l, s );
    *n = (VnusInt) ceildiv( u, s )-*shift;
}

// A union to easily convert between vnus_int and vnus_float and v/v
union intNfloat {
    VnusInt i;
    VnusFloat f;
};

// A union to easily convert between vnus_long and vnus_double and v/v
union longNdouble {
    VnusLong l;
    VnusDouble d;
};

inline VnusDouble VnusLongBitsToDouble( VnusLong n )
{
    longNdouble u;

    u.l = n;
    return u.d;
}

inline VnusFloat VnusIntBitsToFloat( VnusInt n )
{
    intNfloat u;

    u.i = n;
    return u.f;
}

#endif
