// File: outofmemory.h

extern void VnusEventOutOfMemory();
