/* File: applyoa5.h */

extern vnusprog apply_oa5( vnusprog elm, global_context gc );
