/* File: applycbp1.h */

extern vnusprog apply_cbp1( vnusprog elm, global_context gc );
