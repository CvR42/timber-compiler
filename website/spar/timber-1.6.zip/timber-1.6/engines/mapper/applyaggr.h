/* File: applyaggr.h */

extern vnusprog apply_aggr( vnusprog elm, global_context gc );
