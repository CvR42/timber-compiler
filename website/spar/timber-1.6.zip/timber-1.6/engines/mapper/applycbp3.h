/* File: applycbp3.h */

extern vnusprog apply_cbp3( vnusprog elm, global_context gc );
