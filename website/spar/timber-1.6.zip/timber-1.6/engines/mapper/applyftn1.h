/* File: applyftn1.h */

extern vnusprog apply_ftn1( vnusprog elm, global_context gc );
