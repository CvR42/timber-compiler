/* File: applytp0.h */

extern vnusprog apply_tp0( vnusprog elm, global_context gc );
