/* File: applymergecond.h */

extern vnusprog apply_mergecond( vnusprog elm, global_context gc );
extern bool hasFired_mergecond();
