/* File: parseowners.h */

extern vnusprog parse_owners( vnusprog elm, global_context gc );
