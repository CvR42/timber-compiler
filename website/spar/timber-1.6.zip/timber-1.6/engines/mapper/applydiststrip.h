/* File: applydiststrip.h */

extern vnusprog apply_dist_strip( vnusprog elm, global_context gc );
