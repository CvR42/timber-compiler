/* File: applycbp2.h */

extern vnusprog apply_cbp2( vnusprog elm, global_context gc );
