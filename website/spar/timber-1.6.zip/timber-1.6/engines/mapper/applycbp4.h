/* File: applycbp4.h */

extern vnusprog apply_cbp4( vnusprog elm, global_context gc );
