/* File: applyclean2.h */

extern vnusprog apply_clean2( vnusprog elm, global_context gc );
