/* File: applyio3.h */

extern vnusprog apply_io3( vnusprog elm, global_context gc );
