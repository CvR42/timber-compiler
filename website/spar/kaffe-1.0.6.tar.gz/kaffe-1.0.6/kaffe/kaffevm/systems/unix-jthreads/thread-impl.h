/*
 * Copyright (c) 1996, 1997, 1998, 1999
 *      Transvirtual Technologies, Inc.  All rights reserved.
 *
 * This file is licensed under the terms of the GNU Public License.
 *
 * See the file "license.terms" for information on usage and redistribution 
 * of this file.
 */

#ifndef __thread_impl_h
#define __thread_impl_h

#define UNIX_JTHREADS

#include "jthread.h"

#endif /* __thread_impl_h */
