kaffe -jar TextEdit.jar $*
