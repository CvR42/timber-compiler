#! /bin/sh
kaffe WidgetsDemo
