public class SignedShort
{
	public static void main(String[]args)
	{ 
		short []arr = {-1}; 
		System.out.println(arr[0]);
	}
}

/* Expected Output:
-1
*/
