class finaltest2 {
    final static double PI = 3.1415926536;
}

// java args: finaltest
/* Expected Output:
3.1415926536000001
*/
