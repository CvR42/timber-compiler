// File: getprim.cc

#include <vnustypes.h>
#include <vnusstd.h>
#include "spar-rtl.h"

void *Java_java_lang_Class_getPrimitiveClass( VnusString s )
{
    (void) s;
    return (void *) NULL;
}
