/* File: prettyprint.h
 *
 * Header declarations for prettyprint.c.
 */

extern void pp_SparProgram( FILE *f, SparProgram theprog );
