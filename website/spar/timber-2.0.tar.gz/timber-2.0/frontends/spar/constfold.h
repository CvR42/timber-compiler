/* File: constfold.h */

extern expression constant_fold_expression( expression x );
extern SparProgram constant_fold_SparProgram( SparProgram x );
