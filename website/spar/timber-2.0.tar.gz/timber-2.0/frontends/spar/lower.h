/* File: lower.h */

extern SparProgramUnit lower_SparProgramUnit( SparProgramUnit unit );
