// File: isgc.h

extern bool is_GC_statement( const_Entry_list symtab, const_statement smt );
