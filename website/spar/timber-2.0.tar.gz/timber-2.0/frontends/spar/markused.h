// File: markused.h

extern void markused_SparProgram( SparProgram prog );
