// File: countrefs.h

extern void countrefs_Block( const_Block decl, Entry_list symtab, int step );
