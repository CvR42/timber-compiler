/* File: applypcp3.h */

extern vnusprog apply_pcp3( vnusprog elm, global_context gc );
