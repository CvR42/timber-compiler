/* File: applyio2.h */

extern vnusprog apply_io2( vnusprog elm, global_context gc );
