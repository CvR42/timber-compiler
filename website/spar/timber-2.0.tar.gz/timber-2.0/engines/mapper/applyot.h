/* File: applyot.h */

extern vnusprog apply_ot( vnusprog elm, global_context gc );
