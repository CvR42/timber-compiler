/* File: applytaskpar.h */

extern vnusprog apply_taskpar( vnusprog elm, global_context gc );
