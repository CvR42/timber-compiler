/* File: applymergeloop.h */

extern vnusprog apply_mergeloop( vnusprog elm, global_context gc );
