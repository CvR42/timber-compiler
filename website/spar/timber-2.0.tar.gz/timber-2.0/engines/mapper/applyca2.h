/* File: applyca2.h */

extern vnusprog apply_ca2( vnusprog elm, global_context gc );
