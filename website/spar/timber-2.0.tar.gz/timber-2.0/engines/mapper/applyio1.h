/* File: applyio1.h */

extern vnusprog apply_io1( vnusprog elm, global_context gc );
