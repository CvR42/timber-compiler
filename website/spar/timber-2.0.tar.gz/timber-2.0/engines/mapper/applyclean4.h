/* File: applyclean4.h */

extern vnusprog apply_clean4( vnusprog elm, global_context gc );
