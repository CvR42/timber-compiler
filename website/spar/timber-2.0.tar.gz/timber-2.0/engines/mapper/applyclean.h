/* File: applyclean.h */

extern vnusprog apply_clean( vnusprog elm, global_context gc );
