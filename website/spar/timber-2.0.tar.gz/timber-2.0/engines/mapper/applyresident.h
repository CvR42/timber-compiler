/* File: applyresident.h */

extern vnusprog apply_resident( vnusprog elm, global_context gc );
