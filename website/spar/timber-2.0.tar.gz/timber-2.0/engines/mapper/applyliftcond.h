/* File: applyliftcond.h */

extern vnusprog apply_liftcond( vnusprog elm, global_context gc );
extern bool hasFired_liftcond();
