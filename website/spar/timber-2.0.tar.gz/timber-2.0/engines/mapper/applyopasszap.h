/* File: applyopasszap.h */

extern vnusprog apply_op_ass_zap( vnusprog elm, global_context gc );
