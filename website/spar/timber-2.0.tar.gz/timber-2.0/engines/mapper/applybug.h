/* File: applybug.h */

extern vnusprog apply_bug( vnusprog elm, global_context gc );
