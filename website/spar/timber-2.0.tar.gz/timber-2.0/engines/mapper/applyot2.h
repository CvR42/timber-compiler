/* File: applyot2.h */

extern vnusprog apply_ot2( vnusprog elm, global_context gc );
