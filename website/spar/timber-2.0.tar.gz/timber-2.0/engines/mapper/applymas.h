/* File: applymas.h */

extern vnusprog apply_mas( vnusprog elm, global_context gc );
