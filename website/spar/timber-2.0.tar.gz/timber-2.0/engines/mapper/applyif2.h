/* File: applyif2.h */

extern vnusprog apply_if2( vnusprog elm, global_context gc );
