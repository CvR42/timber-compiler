/* File: decompose.h */

extern vnusprog apply_decompose( vnusprog elm);
