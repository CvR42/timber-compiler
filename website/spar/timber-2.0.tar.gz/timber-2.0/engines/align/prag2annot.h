/* File: prag2annot.h */

extern vnusprog apply_p2a( vnusprog elm);
