/* File: clear_on.h */

extern vnusprog apply_clear_on( vnusprog elm);
