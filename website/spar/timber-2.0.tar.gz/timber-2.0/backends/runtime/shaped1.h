// File: shaped1.h

#ifndef __SHAPED1_H__
#define __SHAPED1_H__

#include "polywrite.h"
#include "vnusstd.h"
#include "shapebase.h"
#include "arrayboundviolated.h"
//HACK
#include <stdio.h>
#include <string.h>
#include <new>

template<class T> class ShapeD1 : public ShapeBase<T>
{
  public:
    ShapeD1( VnusBase::markfntype markfn, const VnusInt card0 ):
     ShapeBase<T>( markfn, card0 )
    {
	this->values = (T *) vnus_alloc_array( sizeof( T ), this->size, true );
    }
    
        // Constructor for intialized arrays.
    ShapeD1( VnusBase::markfntype markfn, T *arr, const VnusInt asz, const VnusInt card0 ):
     ShapeBase<T>( markfn, card0 )
    {
        if( asz != this->size ){
            fprintf(stderr,"*** ERROR -- \n");
            fprintf(stderr,"    Initializer array has %d  elms, but %d elms are required\n",asz, this->size );
            exit(1);
        }
	this->values = (T *) vnus_alloc_array( sizeof( T ), this->size, false );
	memcpy( this->values, arr, sizeof( T )*asz );
    }

    inline ShapeD1( const ShapeD1<T>& theShape):
     ShapeBase<T>(theShape)
    {
    }
    
    virtual inline ~ShapeD1()
    {
    }

    // Assign one shape to another, but only if they are exactly alike.
    // This should not be used... I hope...
    ShapeD1<T>& operator= (const ShapeD1<T>& theShape)
    {
        if( this == &theShape ){
            return *this;
        }
	if( this->size != theShape.GetSize(0) ){
	    fprintf(stderr, "*** ERROR -- \n");
	    fprintf(stderr, "    Sizes don't match in dimension 0 (%d != %d)\n",this->size,theShape.GetSize(0));
	    exit(1);
	}
        ShapeBase<T>::operator=(theShape);
        return *this;
    }

    inline T& operator() ( const VnusInt i0 ) const
    {
        return AccessChecked( i0 );
    }

    inline T& AccessChecked( const VnusInt i0 ) const
    {
        CheckIndex( i0 );
        return this->values[i0];
    }

    // Access to a shape element.
    // Similar to above, but these functions are not virtual.
    // Access to these functions is generated if it is known whether
    // the array is a shape.
    inline T& AccessNotChecked( const VnusInt i0 ) const
    {
        return this->values[i0];
    }

    inline void CheckIndex( const VnusInt i0 ) const
    {
	if( ((UnsignedVnusInt) i0) >= (UnsignedVnusInt) this->size ){
	    VnusEventArrayBoundViolated();
	}
    }

    inline VnusInt GetSize( const VnusInt dim ) const
    {
	switch( dim ){
	    case 0:
		return this->size;

	    default:
		runtime_error( "ShapeD1::GetSize: Illegal dimension" );
		return -1;

	}
    }

    void PrintInfo( FILE* out )
    {
        fprintf(out,"Shape[rank:1,size:%d",this->size);
        fprintf(out,"]");
    }
    

    inline ShapeD1<T>* Fill (const T defaultValue)
    {
        return (ShapeD1<T>*)ShapeBase<T>::Fill(defaultValue);
    }

};

#endif
