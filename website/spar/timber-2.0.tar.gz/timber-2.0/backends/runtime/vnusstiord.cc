//
// This is code generated through Tm.
//
/*
 * Distributed read functions use broadcasts!
 */

#include "vnusstio.h"
#include "io/ioseq.h"
#include "io/iopar.h"
#include "../runtime/vnusrtl.h"
#include <stdio.h>

VnusInt vp__readByte(VnusInt fileHandle, VnusByte *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readByte(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readShort(VnusInt fileHandle, VnusShort *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readShort(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readInt(VnusInt fileHandle, VnusInt *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readInt(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readLong(VnusInt fileHandle, VnusLong *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readLong(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readFloat(VnusInt fileHandle, VnusFloat *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readFloat(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readDouble(VnusInt fileHandle, VnusDouble *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readDouble(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readComplex(VnusInt fileHandle, VnusComplex *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readComplex(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readBoolean(VnusInt fileHandle, VnusBoolean *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readBoolean(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readChar(VnusInt fileHandle, VnusChar *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readChar(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
VnusInt vp__readString(VnusInt fileHandle, VnusString *elt)
{
    VnusInt result = NOT_EXECUTED;
    if (isThisProcessor(0))
    {
        result = vs__readString(fileHandle, elt);
        vnus_broadcast(sizeof(*elt), elt);
    }
    vnus_receive(0, sizeof(*elt), elt);
    vnus_wait_pending();
    return result;
}
