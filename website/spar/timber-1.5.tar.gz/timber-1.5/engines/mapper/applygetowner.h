/* File: applygetowner.h */

extern vnusprog apply_get_owner( vnusprog elm, global_context gc );
