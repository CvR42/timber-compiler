/* File: applyopt.h */

extern vnusprog apply_opt( vnusprog elm, global_context gc );
