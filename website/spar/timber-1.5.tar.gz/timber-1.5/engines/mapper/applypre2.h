/* File: applypre2.h */

extern vnusprog apply_pre2( vnusprog elm, global_context gc );
