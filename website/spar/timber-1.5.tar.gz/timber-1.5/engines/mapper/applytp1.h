/* File: applytp1.h */

extern vnusprog apply_tp1( vnusprog elm, global_context gc );
