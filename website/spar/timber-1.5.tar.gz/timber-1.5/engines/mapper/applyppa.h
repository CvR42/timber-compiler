/* File: applyppa.h */

extern vnusprog apply_ppa( vnusprog elm, global_context gc );
