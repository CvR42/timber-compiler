/* File: search.h */

extern int search_expression_list( expression_list elm, tmsymbol sym );
extern int search_expression( expression elm, tmsymbol sym );
extern int search_cardinality_list( cardinality_list elm, tmsymbol sym );
extern int search_cardinality( cardinality elm, tmsymbol sym );
