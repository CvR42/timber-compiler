/* File: applypcp0.h */

extern vnusprog apply_pcp0( vnusprog elm, global_context gc );
