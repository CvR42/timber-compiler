/* File: applycbp6.h */

extern vnusprog apply_cbp6( vnusprog elm, global_context gc );
