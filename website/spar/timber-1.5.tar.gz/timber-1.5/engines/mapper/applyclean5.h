/* File: applyclean5.h */

extern vnusprog apply_clean5( vnusprog elm, global_context gc );
