/* File: applyif4.h */

extern vnusprog apply_if4( vnusprog elm, global_context gc );
