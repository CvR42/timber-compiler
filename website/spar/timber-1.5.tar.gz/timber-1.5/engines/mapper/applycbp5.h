/* File: applycbp5.h */

extern vnusprog apply_cbp5( vnusprog elm, global_context gc );
