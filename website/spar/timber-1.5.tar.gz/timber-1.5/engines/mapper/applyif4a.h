/* File: applyif4a.h */

extern vnusprog apply_if4a( vnusprog elm, global_context gc );
