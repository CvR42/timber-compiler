/* File: applytag.h */

extern vnusprog apply_tag( vnusprog elm );
