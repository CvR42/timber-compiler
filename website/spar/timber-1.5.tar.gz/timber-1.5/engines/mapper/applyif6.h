/* File: applyif6.h */

extern vnusprog apply_if6( vnusprog elm, global_context gc );
