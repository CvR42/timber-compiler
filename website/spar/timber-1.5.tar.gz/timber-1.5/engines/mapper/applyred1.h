/* File: applyred1.h */

extern vnusprog apply_red1( vnusprog elm, global_context gc );
