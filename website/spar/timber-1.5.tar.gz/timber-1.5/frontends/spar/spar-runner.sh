#
# This is only a partial script. It must be prefixed with a
# configuration file to get it running.
#
CPLUS=g++

# Some stuff for use on the DAS, should be more configurable later...
PANDA=/usr/local/VU/panda/panda4.0
PANDA_ARCH=i386_linux/lfc/no_threads/optimized
DASLIB=/usr/local/package/daslib
LFCLIB=/usr/local/package/lfc/lib
LFCVERSION=optimized

# Some stuff for on the Babylon, should be more configurable later...
PVM_ROOT=${PVM_ROOT:-/usr/local/pvm3}

# Clear flags to the various phases
CPLUSFLAGS=
VNUSFLAGS=
FRONTFLAGS=
LDFLAGS=
MAPPERFLAGS=

# lists of files
SPARFILES=
VNUSFILES=
CPLUSFILES=
LDFILES=
LIBS=
JUNK=
VERIFYMODE=0

OUTPUT=a.out
N=0
TRACE=
FAIL=0
KEEPFILES=0
NEEDSPARRTL=1 # always set to one for compiling intermediate C++ files
COMBINE_COMPILE_LINK=0
TARGET=default
PROCNO=default
ALVL=2
COMMLIB=undetermined
EXECUTE=0


function showversion()
{
    echo "$0 version $VERSION";
}

function showversions()
{
    showversion
    $FRONT -v
    $VNUS -v
    $CPLUS -v
}

function showusage()
{
    showversion
    cat << EOF
Usage: $0 [options] <file>

Files with the extension '.spar' and '.java' are put through Spar.

Files with the extension '.v' are put through Vnus.

Files with the extensions '.c', '.cc', '.cpp' and '.cxx' are put through C++.

Files with the extensions '.o' and '.a' are linked with the other files.

Options are:
--help            Show this help text
--version         Print the version number of this driving scipt
--versions        Print the version numbers of all components of the script
--keepfiles       Keep intermediate files
--compile-link    Combine compile & link step
--timings
--timer           Enable runtime timer
--nocards
--verify	  This is a verify compile.
--noboundscheck   Do not generate array bounds checking code
--nogc            Do not generate garbage collection code
--nocomplex       Do not recognize the 'complex' keyword
--arrayclass	  Passed to Spar frontend
--nodelete        Do not recognize the '__delete' statement
--noeach          Do not recognize 'each' and 'foreach' constructs
--noinline        Do not recognize the 'inline' keyword
--noinlining      Do not inline any methods or constructors
--nopragma        Do not recognize pragmas
--noprint         Do not recognize the '__print' and '__println' keywords
--nonotnullassert Do not generate null pointer checking code
--execute         After compilation, execute the program
--strictanalysis  Strictly adhere to standard Java reachability analysis
--java		  Passed to Spar frontend
--java-array 	  Passed to Spar frontend
-W<flag>	  Passed to Spar frontend
-g                Generate debugging code
-h	          Show this help text
-o <file>	  Write output (executable) to <file>
-O<n>		  Let the C++ backend use optimization level <n>.

-m<flag>          Passed to target C++ compiler
-f<flag>          Passed to target C++ compiler
--par		  Generate parallel code.

Sequential targets:

--target=seq      Compile for sequential target (default)

Distributed targets:

--target=das      Compile for DAS cluster (Panda)
--target=lam      Compile for Babylon cluster (LAM-MPI)
--target=pvm      Compile for Babylon cluster (PVM)

-a<n>             Specify number of processors

EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --compile-link)
            COMBINE_COMPILE_LINK=1
            shift
            ;;

        --execute)
            EXECUTE=1
            shift
            ;;

	--keepfiles)
	    KEEPFILES=1
	    CPLUSFLAGS="$CPLUSFLAGS"
	    shift
	    ;;

	--par)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=host
	    DISTRIBUTED="yes"
            if [ "$COMMLIB" == "undetermined" ]; then
	      COMMLIB=mpi
            fi
            shift
            ;;

        -das|--target=das)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=das
            shift
            ;;

        -lam|--target=lam)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=lam
            shift
            ;;

        -pvm|--target=pvm)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=pvm
            shift
            ;;

        -seq|--target=seq)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=seq
            shift
            ;;

        -trimedia|--target=trimedia)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=trimedia
            COMBINE_COMPILE_LINK=1
            shift
            ;;

        -emb-trimedia)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-trimedia
	    MAPPERFLAGS=
            COMBINE_COMPILE_LINK=1
            shift
            ;;

        -emb-pentium)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-pentium
	    MAPPERFLAGS=
            shift
            ;;

        -emb-trimedia-lus)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-trimedia-lus
	    MAPPERFLAGS=-da
            COMBINE_COMPILE_LINK=1
            shift
            ;;

        -emb-pentium-lus)
            if [ "$TARGET" != "default" ]; then
              echo "Multiple targets specified"
              exit 1
            fi
            TARGET=emb-pentium
	    MAPPERFLAGS=-da
            shift
            ;;

	-pg)
	    CPLUSFLAGS="$CPLUSFLAGS -pg"
	    LDFLAGS="$LDFLAGS -pg"
	    shift
	    ;;

        -a*)
            if [ "$PROCNO" != "default" ]; then
              echo "Multiple processor numbers specified (-a<n>)"
              exit 1
            fi
            PROCNO=$1
            shift
            ;;

	--noinline|--strictanalysis|--noinlining|--nopragma|--noprint|--arrayclass|--nocomplex|--nocards|--nodelete|--java-array|--java|--noeach|-W*|--noboundscheck|--nonotnullassert)
	    FRONTFLAGS="$FRONTFLAGS $1"
	    shift
	    ;;

	--verify)
	    VERIFYMODE=1
	    FRONTFLAGS="$FRONTFLAGS $1"
	    shift
	    ;;

	--timings)
	    TRACE="time -v"
	    shift
	    ;;

	--timer)
	    VNUSFLAGS="$VNUSFLAGS -dt"
	    shift
	    ;;

	--trace)
	    TRACE=echo
	    shift
	    ;;

	--version)
	    showversion
	    exit 0
	    ;;

	--versions)
	    showversions
	    exit 0
	    ;;

	-o)
	    OUTPUT=$2
	    shift
	    shift
	    ;;

	-g)
	    CPLUSFLAGS="$CPLUSFLAGS -g"
	    LDFLAGS="$LDFLAGS -g"
	    shift
	    ;;

	-O*|-f*|-m*|-save-temps)
	    CPLUSFLAGS="$CPLUSFLAGS $1"
	    shift
	    ;;

	-h | --help)
	    showusage
	    exit 0
	    ;;

	-d*)
	    FRONTFLAGS="$FRONTFLAGS $1"
	    shift
	    ;;

	-l*)
	    LIBS="$LIBS $1"
	    shift
	    ;;

	-*)
	    echo "unknown option '$1'"
	    showusage
	    exit 1
	    ;;

	*.v)
	    VNUSFILES="$VNUSFILES $1"
	    shift
	    ;;

	*.spar|*.java)
	    SPARFILES="$SPARFILES $1"
	    NEEDSPARRTL=1
	    shift
	    ;;

	*.c|*.C|*.cc|*.cpp|*.cxx)
	    CPLUSFILES="$CPLUSFILES $1"
	    shift
	    ;;

	*.o)
	    LDFILES="$LDFILES $1"
	    shift
	    ;;

	*.a)
	    LIBFILES="$LIBFILES $1"
	    shift
	    ;;

	*)
	    echo "$0: Don't know what to do with file '$1'"
	    shift
	    FAIL=1
	    ;;
    esac
done

if [ $FAIL = 1 ]; then
    exit 1
fi

if [ "$TARGET" = "default" ] ; then
  TARGET=seq
fi

if [ "$PROCNO" = "default" ] ; then
  PROCNO=-a4
fi

case "$TARGET" in
  seq)
    COMMLIB=sequential
    DISTRIBUTED="no"
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    ;;

  trimedia)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    DISTRIBUTED="no"
    COMMLIB=sequential
    CPLUS="tmcc"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS -l"
    CPLUSFLAGS="$CPLUSFLAGS -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -el -host MacOS -tmcfe -Xtmpl=local --"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -tmconfig=$TMDRV_PATH/dsp/lib/tmconfig.linux-i386 -L$VNUSRUNTIMELIB -L$TMDRV_PATH/dsp/lib"
    LIBFILES="$LIBFILES -ltmdrv -ldev -lvnusio-ts -lvnusrtl-ts"
    if [ $NEEDSPARRTL = 1 ]; then
      LDFLAGS="$LDFLAGS -L$SPARRUNTIMELIB"
      LIBFILES="$LIBFILES -lspar-rtl-ts"
    fi
    ;;

  emb-trimedia|emb-trimedia-lus)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    DISTRIBUTED="yes"
    COMMLIB=ptm
    CPLUS="tmcc"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS -l"
    CPLUSFLAGS="$CPLUSFLAGS -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE -el -host MacOS -tmcfe -Xtmpl=local --"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -tmconfig=$TMDRV_PATH/dsp/lib/tmconfig.linux-i386 -L$VNUSRUNTIMELIB -L$TMDRV_PATH/dsp/lib"
    LIBFILES="$LIBFILES -lvnusio-tp -lvnusrtl-ts -lvnusglue-te $VNUSRUNTIMELIB/embedded/libensemble-trimedia.a -ltmdrv -ldev"
    if [ $NEEDSPARRTL = 1 ]; then
      LDFLAGS="$LDFLAGS -L$SPARRUNTIMELIB"
      LIBFILES="$LIBFILES -lspar-rtl-te"
    fi
    ;;

  emb-pentium|emb-pentium-lus)
    TMDRV_PATH="$HOME/trimedia/tmdrvsrc_1.0"
    TCS_PATH="/usr/local/src/tcs2.0beta"
    DISTRIBUTED="yes"
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    FRONTFLAGS="$FRONTFLAGS"
    LDFLAGS="$LDFLAGS -L$TMDRV_PATH/linux/lib -L$TCS_PATH/lib/Linux -L$VNUSRUNTIMELIB"
    LIBFILES="-lvnusio-p -lvnusrtl-s -lvnusglue-e $VNUSRUNTIMELIB/embedded/libensemble-host-i386.a -ltmdrv -lload $LIBFILES"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;

  host)
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    ;;

  das)
    DISTRIBUTED="yes"
    COMMLIB=panda
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    ;;

  lam)
    DISTRIBUTED="yes"
    COMMLIB=mpi
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    CPLUSFLAGS="-I/usr/local/lam/include -DLAM_BUILDING=0 $CPLUSFLAGS"
    LDFLAGS="$LDFLAGS -L/usr/local/lam/lib"
    ;;

  pvm)
    DISTRIBUTED="yes"
    COMMLIB=pvm
    CPLUS="g++"
    VNUSFLAGS="-Ispar-rtl.h $VNUSFLAGS"
    CPLUSFLAGS="-g -I$SPARRUNTIMEINCLUDE -I$VNUSRUNTIMEINCLUDE $CPLUSFLAGS"
    ;;

  *)
    echo "Internal error: unknown TARGET value '$TARGET'"
    exit 2
    ;;

esac

# Now set libraries and flags for the relevant communication library
case "$COMMLIB" in
  sequential)
    # Sequential means we don't need a communication library
    LDFLAGS="$LDFLAGS -L$VNUSRUNTIMELIB"
    LIBFILES="$LIBFILES -lvnusio-s -lvnusrtl-s"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;

  undetermined)
    echo "Internal error: undetermined COMMLIB value"
    exit 2
    ;;

  ptm)
    ;;

  mpi)
    LDFLAGS="$LDFLAGS -L$VNUSRUNTIMELIB"
    LIBFILES="$LIBFILES -lvnusio-p -lvnusrtl-s -lvnusglue-m -lmpi -ltstdio -ltrillium -largs -lt"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;

  pvm)
    LDFLAGS="$LDFLAGS -L$VNUSRUNTIMELIB -L$PVM_ROOT/lib/LINUX"
    LIBFILES="$LIBFILES -lvnusio-p -lvnusrtl-s -lvnusglue-d -lgpvm3 -lpvm3"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;

  panda)
    LDFLAGS="$LDFLAGS -L/usr/local/package/myrinet/lib/intel_linux -L$PANDA/lib/$PANDA_ARCH -L$LFCLIB/$LFCVERSION -L$DASLIB/lib/i386_Linux -L$VNUSRUNTIMELIB"
    LIBFILES="$LIBFILES -lvnusio-p -lvnusrtl-s -lvnusglue-p -lpanda -llfc -lDpi -lLanaiDevice -lbfd -liberty -ldas"
    if [ $NEEDSPARRTL = 1 ]; then
      LIBFILES="$SPARRUNTIMELIB/libspar-rtl-s.a $LIBFILES"
    fi
    ;;

  *)
    echo "Internal error: unknown COMMLIB value '$COMMLIB'"
    exit 2
    ;;

esac

#
# Spar frontend phase
#
for f in $SPARFILES; do
    if [ $KEEPFILES = 1 ]; then
	case "$f" in
	    *.spar)
		OUT=`basename $f .spar`.v
		;;

	    *.java)
		OUT=`basename $f .java`.v
		;;

	     *)
		echo "$o: Don't know how to get the basename of file '$f'"
		exit 2
		;;
	esac
    else
	OUT=$TMPDIR/spar$$.$N.v
	N=`expr $N + 1`
	JUNK="$JUNK $OUT"
    fi
    VNUSFILES="$OUT $VNUSFILES"
    $TRACE $FRONT $FRONTFLAGS -o $OUT $f
    if [ $? != 0 ]; then
	$TRACE rm -f $JUNK
	exit 1
    fi
done

# If we're in verify mode, we only want to run the frontend
if [ $VERIFYMODE = 1 ]; then
    $TRACE rm -f $JUNK
    exit 0
fi

#
# Vnus phase
#
if [ "$DISTRIBUTED" = "yes" ]; then
  # sequential vnus -> sequential tm -> distributed tm -> c++
  for f in $VNUSFILES; do
      #sequential vnus -> tm
      if [ $KEEPFILES = 1 ]; then
	  OUT_TM_SEQ=`basename $f .v`-s.tm
      else
  	  OUT_TM_SEQ=$TMPDIR/spar$$.$N-s.tm
	  N=`expr $N + 1`
	  JUNK="$JUNK $OUT_TM_SEQ"
      fi
      $TRACE $VNUS -t $PROCNO $f -o $OUT_TM_SEQ

      # run 'initial' engine
      if [ $KEEPFILES = 1 ]; then
	  OUT_INIT_DIST=`basename $f .v`-init.tm
      else
  	  OUT_INIT_DIST=$TMPDIR/spar$$.$N-init.tm
	  N=`expr $N + 1`
	  JUNK="$JUNK $OUT_INIT_DIST"
      fi
#      echo PERFORMING $INITIAL $MAPPERFLAGS
      $TRACE $INITIAL $MAPPERFLAGS < $OUT_TM_SEQ > $OUT_INIT_DIST
      if [ $? != 0 ]; then
	  $TRACE rm -f $JUNK
	  exit 1
      fi

      #sequential tm -> distributed tm
      if [ $KEEPFILES = 1 ]; then
	  OUT_ALIGN_DIST=`basename $f .v`-align.tm
      else
  	  OUT_ALIGN_DIST=$TMPDIR/spar$$.$N-align.tm
	  N=`expr $N + 1`
	  JUNK="$JUNK $OUT_ALIGN_DIST"
      fi
#      echo PERFORMING $ALIGN $MAPPERFLAGS
      $TRACE $ALIGN -l$ALVL $MAPPERFLAGS < $OUT_INIT_DIST > $OUT_ALIGN_DIST

      #sequential tm -> distributed tm
      if [ $KEEPFILES = 1 ]; then
	  OUT_TM_DIST=`basename $f .v`-spmd.tm
      else
  	  OUT_TM_DIST=$TMPDIR/spar$$.$N-spmd.tm
	  N=`expr $N + 1`
	  JUNK="$JUNK $OUT_TM_DIST"
      fi
#      echo PERFORMING $SPMD $MAPPERFLAGS
      $TRACE $SPMD $MAPPERFLAGS < $OUT_ALIGN_DIST > $OUT_TM_DIST
      if [ $? != 0 ]; then
	  $TRACE rm -f $JUNK
	  exit 1
      fi

      #distributed tm -> c++
      if [ $KEEPFILES = 1 ]; then
	  OUT=`basename $f .v`.cc
      else
  	  OUT=$TMPDIR/spar$$.$N.cc
	  N=`expr $N + 1`
	  JUNK="$JUNK $OUT"
      fi
      CPLUSFILES="$OUT $CPLUSFILES"
      $TRACE $VNUS $VNUSFLAGS -r -p $PROCNO $OUT_TM_DIST -o $OUT
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
  done
else
  # sequential vnus -> c++
  for f in $VNUSFILES; do
      if [ $KEEPFILES = 1 ]; then
	  OUT=`basename $f .v`.cc
      else
  	OUT=$TMPDIR/spar$$.$N.cc
	N=`expr $N + 1`
	JUNK="$JUNK $OUT"
      fi
      CPLUSFILES="$OUT $CPLUSFILES"
      $TRACE $VNUS $VNUSFLAGS $f -o $OUT
      if [ $? != 0 ]; then
  	$TRACE rm -f $JUNK
	exit 1
      fi
  done
fi


if [ $COMBINE_COMPILE_LINK = 1 ]; then
    $TRACE $CPLUS $CPLUSFLAGS $LDFLAGS $CPLUSFILES $LDFILES $LIBFILES $LIBS -o $OUTPUT
  {
    if [ $? != 0 ]; then
        $TRACE rm -f $JUNK
        exit 1
    fi
  }
else
  {
    # C++ phase
    for f in $CPLUSFILES; do
        if [ $KEEPFILES = 1 ]; then
	    OUT=`basename $f .cc`.o
        else
	    OUT=$TMPDIR/spar$$.$N.o
            N=`expr $N + 1`
            JUNK="$JUNK $OUT"
        fi
        LDFILES="$OUT $LDFILES"
        $TRACE $CPLUS -c $CPLUSFLAGS $f -o $OUT
        if [ $? != 0 ]; then
	    $TRACE rm -f $JUNK
	    exit 1
        fi
    done
    # link phase
    $TRACE $CPLUS $LDFLAGS $LDFILES $LIBFILES -o $OUTPUT
    if [ $? != 0 ]; then
        $TRACE rm -f $JUNK
        exit 1
    fi
  }
fi

if [ $EXECUTE = 1 ]; then
    $TRACE $OUTPUT
fi

# clean up
$TRACE rm -f $JUNK
