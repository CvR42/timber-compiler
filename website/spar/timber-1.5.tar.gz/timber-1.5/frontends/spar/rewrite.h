/* File: rewrite.h */

extern SparProgram rewrite_SparProgram( SparProgram prog );
