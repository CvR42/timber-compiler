/* File: noreturn.h */

extern Block noreturn_Block( const_origin org, Block blk, tmsymbol retvar );
