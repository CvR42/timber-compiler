/* File: regtype.h */

extern void regtype_TypeDeclaration( SparProgram *prog, TypeDeclaration dcl, SparProgramUnit unit, TypeBinding_list *typebindings, tmsymbol enclosing_type );
extern void regtype_SparProgramUnit( SparProgram *prog, SparProgramUnit unit, const_tmstring fnm );
