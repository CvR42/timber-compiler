// File: typename.h

#ifndef INC_TYPENAME_H
#define INC_TYPENAME_H

extern tmstring name_type( const_declaration_list decls, const_type t );
extern tmstring name_type_list( const_declaration_list decls, const_type_list tl );
extern tmstring name_field_list( const_declaration_list decls, const_field_list tl );

#endif
