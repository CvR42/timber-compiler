extern tmsymbol_list collectscopes_block( const_block blk );
extern tmsymbol_list collectscopes_statement( const_statement blk );
