// File: garbagecollect.h

extern VnusInt VnusEventGarbageCollect();
