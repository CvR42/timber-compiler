// File: shaped0.h

#ifndef __SHAPED0_H__
#define __SHAPED0_H__

#include "polywrite.h"
#include "vnusstd.h"
#include "shapebase.h"
#include "outofmemory.h"
//HACK
#include <stdio.h>
#include <string.h>
#include <new>

template<class T> class ShapeD0 : public ShapeBase<T>
{
  public:
    ShapeD0( VnusBase::markfntype markfn ):
     ShapeBase<T>( markfn, 1 )
    {
	values = (T *) vnus_alloc_array( sizeof( T ), size, true );
    }
    
    inline ShapeD0( const ShapeD0<T>& theShape ):
     ShapeBase<T>( theShape )
    {
    }
    
    virtual inline ~ShapeD0()
    {
    }

    // Assign one shape to another, but only if they are exactly alike.
    // This should not be used... I hope...
    ShapeD0<T>& operator= (const ShapeD0<T>& theShape)
    {
        if( this == &theShape ){
            return *this;
        }
        ShapeBase<T>::operator=(theShape);
        return *this;
    }

    T& operator() () const { return AccessChecked(); }

    T& AccessChecked() const { CheckIndex(); return AccessNotChecked(); }

    // For now the SetSize function does no communication.
    void SetSize()
    {}

    // Access to a shape element.

    inline T& AccessNotChecked() const
    {
        return values[0];
    }

    inline void CheckIndex() const {}

    inline VnusInt Dim() const { return 0; }

    inline VnusInt GetSize( const VnusInt dim ) const
    {
        return 1;
    }

    void PrintInfo( FILE* out )
    {
        fprintf(out,"Shape[rank:0,size:1",0,1);
        fprintf(out,"]");
    }
    

        // Stuff from ShapeBase adapted for 0 dimensions.
    inline VnusInt GetLength() const { return 1; }

/*
 * Fill just allocated Shape with a default value (must be basic type).
 * returns 'this' so that it can be used in new expressions.
 */
    inline ShapeD0<T>* Fill (const T defaultValue)
    {
        return (ShapeD0<T>*)ShapeBase<T>::Fill(defaultValue);
    }

    void Print( FILE out ) const
    {
        pm_write(out,value);
        fprintf(out,"\n");
    }
};

#endif
