// File: shapebase.h

#ifndef __SHAPEBASE_H__
#define __SHAPEBASE_H__

#include <stdio.h>		// For printing methods

#include "polywrite.h"
#include "vnusstd.h"
#include "vnusbaseclass.h"

/*
  Base class for 0-, 1-, 2-, 3- and n-dimensional shapes.
  */
template<class T> class ShapeBase: public VnusBase
{
  protected:
    markfntype markfn;
    VnusInt size;
    T *values;

  public:
    ShapeBase( markfntype p_markfn, VnusInt p_size ):
     VnusBase(), markfn(p_markfn), size(p_size), values(NULL)
    {}
    
    virtual inline ~ShapeBase()
    {
	vnus_free( values );
    }
    
    inline ShapeBase( const ShapeBase<T>& theShape ):
     VnusBase(),
     size(theShape.size)
    {
	values = (T *) vnus_alloc_array( sizeof( T ), size, false );
        for( VnusInt i = 0; i < size; i++ ){
            values[i] = theShape.values[i];
        }
    }
    
    inline VnusInt GetLength() const { return size; }

    /*
     * Fill just allocated Shape with a default value (must be basic type).
     * returns 'this' so that it can be used in new expressions.
     */
    inline ShapeBase<T>* Fill (const T defaultValue)
    {
        for (int i=0; i<size; i++)
            values[i] = defaultValue;
        return this;
    }

    ShapeBase<T>& operator= (const ShapeBase<T>& theShape)
    {
        if( this == &theShape ){
            return *this;
        }
        if( size != theShape.size ){
            fprintf(stderr, "*** ERROR -- \n");
            fprintf(stderr, "    Sizes don't match (%d != %d)\n",size,theShape.size);
            exit(1);
        }        
        for( VnusInt i = 0; i < size; i++ ){
            values[i] = theShape.values[i];
        }
        return *this;
    }

    // Subscript operator for flat selection access.
    inline T& operator[]( const int i ) const { return values[i]; }

    inline T* Getbuf() const { return values; }

    inline markfntype getShapeMarkfn() const { return markfn; }

    inline bool isShape() const { return true; }

    void Print( FILE *out ) const
    {
        for( VnusInt i = 0; i<size; i++ ){
            pm_write(out,values[i]);
            fprintf(out," ");
        }
        fprintf(out,"\n");
    }
};

inline VnusBase *vnus_get_shape_buffer( VnusBase *arr )
{
    ShapeBase<int> *arr1 = (ShapeBase<int> *) arr;
    return (VnusBase *) arr1->Getbuf();
}

inline VnusInt vnus_get_shape_length( VnusBase *arr )
{
    ShapeBase<int> *arr1 = (ShapeBase<int> *) arr;
    return arr1->GetLength();
}
#endif
